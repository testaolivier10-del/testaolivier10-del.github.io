"""Art for w1124-02-ball-feather: a giant vacuum chamber (ribbed aluminium walls, dome lights), a drop rig with two clamps, a bowling ball,
a feather, a padded landing box. House flat style; cool light from the dome above. World = screen at zoom 1; she stands lower left."""
import sys, math
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/lib']
import numpy as np, skia
from lpk import P, SP, C, blur, smooth, lerp, mix, poly, smooth_closed
from art import shaded, diffp, tube, op, glow, SCREEN

BX, FX = 700, 900                 # ball and feather x
Y0, YF = 640, 1296                # ball centre hanging / resting on the pad
BR = 64                           # ball radius
FLOOR = 1370
_R = np.random.default_rng(4)
MOTES = [(_R.uniform(40, 1040), _R.uniform(420, 1500), _R.uniform(2.5, 6), _R.uniform(0, 6.28), _R.uniform(0.4, 1.0)) for _ in range(90)]
BOKEH = [(_R.uniform(-60, 1140), _R.uniform(300, 1300), _R.uniform(30, 80), _R.uniform(0, 6.28), i % 3) for i in range(22)]
WALL_A, WALL_B, WALL_HI = (88, 108, 142), (46, 58, 92), (170, 196, 226)


def chamber(c, t, vac=0.0):
    """the inside of the chamber: a ring of tall ribbed panels curving round, hoops, dome lights, a door seam, a polished floor"""
    sh = skia.GradientShader.MakeLinear([skia.Point(0, -200), skia.Point(0, 1500)], [C((30, 40, 72)), C(mix(WALL_A, (70, 96, 150), 0.3 * vac)), C(WALL_B)], [0, 0.45, 1])
    c.drawRect(skia.Rect(-400, -400, 1480, 1500), skia.Paint(Shader=sh))
    for i in range(-3, 15):                                    # panels: narrower toward the sides as the wall curves away
        u = (i + 0.5) / 12.0; x = 540 + 720 * math.sin((u - 0.5) * 2.1); x1 = 540 + 720 * math.sin(((i + 1.5) / 12.0 - 0.5) * 2.1)
        k = abs(u - 0.5) * 2
        c.drawRect(skia.Rect(x, -400, x1, 1420), P(mix(WALL_A, WALL_B, 0.25 + 0.6 * min(1, k)), 255))
        c.drawRect(skia.Rect(x, -400, x + 7, 1420), P(WALL_HI, 120 * (1 - 0.7 * min(1, k))))                 # the rib catching the dome light
        c.drawRect(skia.Rect(x1 - 9, -400, x1, 1420), P((26, 34, 62), 150))
    for y, w in ((180, 14), (520, 12), (860, 12), (1180, 10)):                                             # hoops round the wall
        p = skia.Path(); p.moveTo(-400, y - 26); p.quadTo(540, y + 46, 1480, y - 26)
        c.drawPath(p, SP((30, 40, 70), w + 8, 150)); c.drawPath(p, SP(WALL_HI, 3, 130))
    c.drawRect(skia.Rect(60, 700, 68, 1420), P((20, 26, 50), 200)); c.drawRect(skia.Rect(-400, 692, 64, 700), P((20, 26, 50), 200))   # the big door, sealed
    for i in range(5):                                         # dome lights with soft cones; they come on one after another at the start
        x = 150 + i * 195; fl = (0.9 + 0.1 * math.sin(t * 3.1 + i * 2)) * smooth((t - 0.1 - i * 0.2) / 0.12)
        glow(c, x, 60, 250, (190, 220, 255), 120 * fl)
        cone = poly([(x - 40, 40), (x + 40, 40), (x + 230, 1400), (x - 230, 1400)])
        c.drawPath(cone, skia.Paint(AntiAlias=True, Color=C((170, 205, 255), 13 * fl), BlendMode=SCREEN, MaskFilter=blur(30)))
    fl = skia.GradientShader.MakeLinear([skia.Point(0, FLOOR - 70), skia.Point(0, 2000)], [C((70, 86, 120)), C((34, 42, 70)), C((14, 18, 36))], [0, 0.4, 1])
    p = skia.Path(); p.moveTo(-400, FLOOR - 40); p.quadTo(540, FLOOR - 110, 1480, FLOOR - 40); p.lineTo(1480, 2400); p.lineTo(-400, 2400); p.close()
    c.drawPath(p, skia.Paint(Shader=fl, AntiAlias=True))
    for i in range(7):                                         # floor plates in perspective
        yy = FLOOR - 20 + i * i * 14
        q = skia.Path(); q.moveTo(-400, yy + 30); q.quadTo(540, yy - 30, 1480, yy + 30); c.drawPath(q, SP((120, 146, 190), 2, 60))
    c.drawOval(skia.Rect(BX - 330, FLOOR - 16, FX + 250, FLOOR + 150), P((150, 190, 255), 26, MaskFilter=blur(40)))      # light pooling under the rig


def vents(c, t, pump=0.0):
    for x, s in ((16, 1), (1064, -1)):
        for k in range(3):
            y = 760 + k * 170
            c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x - 22, y - 52, x + 22, y + 52), 10, 10), P((22, 28, 54)))
            for j in range(5): c.drawLine(x - 16, y - 36 + j * 18, x + 16, y - 36 + j * 18, SP((110, 136, 180), 3, 200))
            if pump > 0.02: glow(c, x, y, 90, (120, 220, 255), 90 * pump * (0.7 + 0.3 * math.sin(t * 9 + k)))


def air(c, t, amount, pump_t):
    """air shown as drifting motes; when the pumps run each one streams to the nearest wall vent and is gone"""
    for i, (x, y, r, ph, a) in enumerate(MOTES):
        px = x + 16 * math.sin(t * 0.6 + ph); py = y + 12 * math.cos(t * 0.5 + ph * 1.7)
        k = 0.0
        if pump_t is not None:
            k = smooth((pump_t - 0.9 * (i % 9) / 9.0) / 0.9)
            vx = 16 if x < 540 else 1064; vy = 760 + (i % 3) * 170
            px = lerp(px, vx, k * k); py = lerp(py, vy, k)
        al = amount * (1 - smooth((k - 0.8) / 0.2)) * a
        if al > 0.01: c.drawCircle(px, py, r, P((200, 226, 255), 150 * al)); c.drawCircle(px, py, r * 2.4, P((160, 200, 255), 36 * al, MaskFilter=blur(4)))


def rig(c, t, open_=0.0):
    """the gantry beam and the two clamps; open_ 0..1 swings the jaws apart"""
    c.drawRect(skia.Rect(BX - 150, 476, FX + 130, 506), P((36, 44, 76))); c.drawRect(skia.Rect(BX - 150, 476, FX + 130, 484), P((150, 176, 214)))
    for x in (BX - 120, FX + 100): c.drawRect(skia.Rect(x - 8, -400, x + 8, 480), P((30, 38, 68))); c.drawRect(skia.Rect(x - 8, -400, x - 4, 480), P((120, 146, 190), 160))
    for x, w, yb in ((BX, 34, Y0 - BR), (FX, 16, Y0 + BR - 156)):
        c.drawRect(skia.Rect(x - 12, 506, x + 12, yb - 26), P((52, 62, 100))); c.drawRect(skia.Rect(x - 12, 506, x - 6, yb - 26), P((150, 176, 214), 180))
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x - 30, yb - 34, x + 30, yb - 14), 6, 6), P((240, 180, 60))); c.drawRect(skia.Rect(x - 30, yb - 34, x + 30, yb - 28), P((255, 226, 140)))
        for sgn in (-1, 1):                                    # the jaws
            c.save(); c.translate(x + sgn * w * 0.5, yb - 16); c.rotate(-sgn * 58 * open_)
            jw = poly([(-5 * sgn, 0), (6 * sgn, 0), (5 * sgn, 26), (-3 * sgn, 34), (-9 * sgn, 26)]); c.drawPath(jw, P((200, 210, 226))); c.drawPath(diffp(jw, (3, 0)), P((120, 134, 160)))
            c.restore()


def ball(c, x, y, a=1.0, ghost=False, rot=0.0):
    if a <= 0.01: return
    b = skia.Path(); b.addCircle(x, y, BR)
    if ghost:
        c.drawPath(b, P((255, 255, 255), 34 * a)); c.drawPath(b, skia.Paint(AntiAlias=True, Color=C((255, 255, 255), 220 * a), Style=skia.Paint.kStroke_Style, StrokeWidth=5, PathEffect=skia.DashPathEffect.Make([16, 12], 0)))
        return
    c.drawPath(b, P((196, 52, 70))); c.drawPath(diffp(b, (-12, -12)), P((132, 30, 64))); c.drawPath(diffp(b, (5, 6)), P((255, 150, 140), 230))
    c.save(); c.clipPath(b, skia.ClipOp.kIntersect, True)
    c.drawOval(skia.Rect(x - 44, y - 50, x - 4, y - 22), P((255, 220, 210), 120, MaskFilter=blur(5)))
    for dx, dy in ((-10, -16), (14, -22), (6, 6)):             # finger holes
        hx = x + (dx * math.cos(rot) - dy * math.sin(rot)); hy = y + (dx * math.sin(rot) + dy * math.cos(rot))
        c.drawCircle(hx, hy, 8.5, P((70, 14, 40))); c.drawCircle(hx + 1.5, hy + 2, 6, P((40, 8, 28)))
    c.restore()


def feather(c, x, y, a=1.0, ghost=False, rot=0.0, s=1.0):
    """(x, y) = the top of the quill, where the clamp holds it; the vane hangs below"""
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    vane = smooth_closed([(0, 22), (20, 36), (30, 70), (28, 110), (16, 140), (0, 156), (-14, 140), (-24, 108), (-26, 70), (-18, 36)])
    if ghost:
        c.drawPath(vane, P((255, 255, 255), 34 * a)); c.drawPath(vane, skia.Paint(AntiAlias=True, Color=C((255, 255, 255), 220 * a), Style=skia.Paint.kStroke_Style, StrokeWidth=4, PathEffect=skia.DashPathEffect.Make([12, 10], 0)))
        c.drawLine(0, 0, 0, 150, SP((255, 255, 255), 3, 200 * a)); c.restore(); return
    c.drawPath(vane, P((244, 246, 250))); c.drawPath(diffp(vane, (-7, 0)), P((186, 198, 222))); c.drawPath(diffp(vane, (3, 3)), P((255, 255, 255)))
    c.save(); c.clipPath(vane, skia.ClipOp.kIntersect, True)
    for k in range(9):                                         # barbs
        yy = 34 + k * 14
        c.drawLine(0, yy, 30, yy - 16, SP((170, 184, 212), 2, 170)); c.drawLine(0, yy, -28, yy - 14, SP((150, 166, 198), 2, 170))
    c.restore()
    c.drawLine(0, 0, 0, 152, SP((214, 196, 150), 4.5)); c.drawLine(0, 0, 0, 24, SP((236, 222, 180), 6))
    c.restore()


def pad(c, dent_b=0.0, dent_f=0.0):
    """the padded landing box; the ball presses a dent into it, the feather does not"""
    top = FLOOR - 44
    p = skia.Path(); p.moveTo(BX - 150, top)
    p.quadTo(BX - 70, top, BX - 60, top + 14 * dent_b); p.quadTo(BX, top + 30 * dent_b, BX + 60, top + 14 * dent_b); p.quadTo(BX + 70, top, BX + 130, top)
    p.lineTo(FX + 130, top); p.lineTo(FX + 130, FLOOR + 10); p.lineTo(BX - 150, FLOOR + 10); p.close()
    c.drawOval(skia.Rect(BX - 190, FLOOR - 6, FX + 170, FLOOR + 44), P((6, 8, 24), 130, MaskFilter=blur(14)))
    c.drawPath(p, P((60, 150, 160))); c.drawPath(diffp(p, (0, -14)), P((34, 96, 120))); c.drawPath(diffp(p, (0, 5)), P((150, 232, 226), 230))
    for x in range(int(BX) - 100, int(FX) + 120, 70): c.drawLine(x, top + 16, x, FLOOR + 4, SP((34, 96, 120), 3, 150))


def arrow(c, x, y0, y1, col, w=16, a=1.0, label=None, size=40):
    if a <= 0.01 or abs(y1 - y0) < 4: return
    c.drawLine(x, y0, x, y1 - 22, SP(col, w, 255 * a))
    c.drawPath(poly([(x - w * 1.5, y1 - 26), (x + w * 1.5, y1 - 26), (x, y1 + 6)]), P(col, 255 * a))


def face_bg(c, t, key=(190, 220, 255), key_side=1):
    """behind her in the close shot: the far wall of the chamber, out of focus"""
    sh = skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, 1920)], [C((30, 40, 76)), C((62, 82, 128)), C((22, 28, 56))], [0, 0.5, 1])
    c.drawRect(skia.Rect(0, 0, 1080, 1920), skia.Paint(Shader=sh))
    c.saveLayer(None, skia.Paint(ImageFilter=skia.ImageFilters.Blur(14, 14)))
    for i in range(9):
        x = -60 + i * 150 + 10 * math.sin(t * 0.2); c.drawRect(skia.Rect(x, 0, x + 12, 1920), P((150, 180, 220), 120)); c.drawRect(skia.Rect(x + 130, 0, x + 142, 1920), P((18, 24, 50), 150))
    for y in (420, 1000): c.drawRect(skia.Rect(0, y, 1080, y + 22), P((24, 32, 62), 190))
    c.restore()
    for x, y, r, ph, k in BOKEH:
        c.drawCircle(x + 12 * math.sin(t * 0.3 + ph), y + 8 * math.cos(t * 0.25 + ph), r, skia.Paint(AntiAlias=True, Color=C([(170, 210, 255), (120, 230, 220), (255, 220, 170)][k], 30 + 22 * (0.5 + 0.5 * math.sin(t * 0.9 + ph))), BlendMode=SCREEN, MaskFilter=blur(5)))
    glow(c, 540 + key_side * 600, 700, 900, key, 90)
