import sys; sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/drop', '/home/claude/w1124/lib']
import build as B
import mixlib as X
OUT = '/home/claude/w1124/drop/out'
fx = [('door_close_real', 0.9, 0.5, 0.5, 0.3, 0.0),                       # the rig locks into place
      ('whoosh_real', B.T_PUMPS - 0.2, 0.55, 2.2, 1.2, 0.0),               # air rushing out through the vents (the pumps, not a cut)
      (X.tick(1800, 0.06), B.T_REL - 0.05, 0.9, None, 0.04, 0.0),         # the clamps open
      ('bagdrop_real', B.T_LAND, 1.0, 0.7, 0.4, 0.0)]                      # the ball lands on the pad (heard in the control room through the floor)
secs = [(0, 8.0), (8.0, 13.7), (13.7, 19.9), (19.9, 27.9), (27.9, 33.0), (33.0, B.DUR)]
X.mix(OUT, '/home/claude/w1124/drop/snd/a.mp3', B.DUR, fx, None, secs, [(0, 1.0), (B.T_REL - 0.5, 0.9), (B.T_REL, 0.55), (B.T_LAND - 0.1, 0.55), (B.T_LAND + 0.2, 1.3), (B.DUR, 1.2)])
if '--encode' in sys.argv: X.encode(OUT)
