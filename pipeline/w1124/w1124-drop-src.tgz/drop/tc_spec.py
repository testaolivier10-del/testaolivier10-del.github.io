SPEC = {"beats": [{"vo": open("/home/claude/w1124/drop/vo.txt").read().strip()}]}
