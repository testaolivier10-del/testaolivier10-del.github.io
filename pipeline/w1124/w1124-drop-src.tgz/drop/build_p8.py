"""w1124-02-ball-feather (AP Physics 1, free fall and Newton's second law). 1080x1920, 30 fps, all code.
Logline: she drops a bowling ball and a feather together inside a giant vacuum chamber, and with the air gone they land at the same moment.
She watches from the control room window (nobody can stand inside a pumped out chamber). Person: a test engineer, designed new (round afro,
cobalt work jacket, deep brown skin), the approved back view and face model.
Shots: wide through the window, the rig lowers the ball and feather (0 to Q) / her face, which first? / in air (dashed ghosts, labelled): the ball
drops fast, the feather drifts / the pumps pull the air out (motes stream to the vents, gauge falls) / pull arrows, mass tags, equal acceleration /
the clamps open, slow motion fall side by side, they land together / her face / wide, end line.
Motion list (accuracy): in air drag is large compared with the feather's weight, small compared with the ball's; in vacuum a = g for both
(force and mass both scale, F/m is the same); both released from rest at the same height at the same instant, same distance fallen at every
frame (y = y0 + H u squared); the feather does not flutter in vacuum; no dust on landing; the ghosts are marked as an illustration (IN AIR)."""
import sys, math, os
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/drop', '/home/claude/w1124/lib']
import numpy as np, skia
import char as CH, dart as D
import kit, lpk, art as A
import layout as L
from kit import Words, Short, ease_io, Wt, Y, R, TL
from lpk import P, SP, C, blur, smooth, lerp, mix, poly

CH.SW, CH.SW_SH, CH.SW_HI = (48, 96, 206), (30, 58, 150), (150, 190, 255)
CH.SKIN, CH.SKIN_SH, CH.SKIN_HI = (150, 98, 72), (108, 64, 56), (200, 150, 118)
CH.HAIR, CH.HAIR_SH, CH.HAIR_HI = (34, 26, 30), (18, 12, 20), (104, 90, 110)
CH.JEAN, CH.JEAN_SH = (52, 56, 70), (32, 34, 48)
CH.HAIRSTYLE = 'afro'
CH.X0 = 418                                           # she stands clear of the corner tag and the button
KEYL = (190, 220, 255)

WD = Words('/home/claude/w1124/drop/out/words.json'); at = WD.at
T_Q, T_IN, T_WINS, T_BEC = at('which'), at('in'), at('wins'), at('because')
T_BUT, T_PUMPS, T_AIR2 = at('but'), at('pumps'), at('air.') if False else at('air', 3)
T_GRAV, T_BUT2, T_THOSE, T_CANCEL = at('gravity'), at('but', 2), at('those'), at('cancel')
T_SO, T_GO, T_FALL, T_TOG, T_WITH, T_EVERY = at('so'), at('go'), at('fall'), at('together'), at('with'), at('everything')
T_REL, T_LAND = T_GO + 0.45, T_TOG + 0.22
T_END = WD.end() + 0.35; DUR = T_END + 1.5
CU1, CU2 = (T_Q - 0.15, T_IN - 0.12), (T_WITH - 0.25, T_EVERY - 0.05)
H = (D.FLOOR - 44) - (D.Y0 + D.BR)                    # both fall this far: bottoms start level, and land level
FY = D.Y0 + D.BR - 156                                # top of the feather's quill in the clamp
TEALC = (90, 220, 200)


def keys(ks, t):
    if t <= ks[0][0]: return ks[0][1:]
    for a, b in zip(ks, ks[1:]):
        if a[0] <= t < b[0]:
            u = ease_io((t - a[0]) / (b[0] - a[0])); return tuple(lerp(x, y, u) for x, y in zip(a[1:], b[1:]))
    return ks[-1][1:]


def pop(t, t0, d=0.25):
    if t < t0: return 0.0
    u = min(1.0, (t - t0) / d) - 1; return 1 + 3.2 * u ** 3 + 2.2 * u ** 2


CAM = [(0, 1.0, 540, 960), (CU1[0], 1.05, 550, 950), (CU1[1], 1.0, 540, 960), (T_BUT, 1.04, 540, 950), (T_PUMPS + 1.2, 1.0, 540, 960),
       (T_GRAV + 0.8, 1.08, 570, 910), (T_SO - 0.3, 1.08, 565, 912), (T_GO, 1.03, 520, 950), (T_REL + 0.3, 1.03, 524, 954), (T_LAND, 1.06, 545, 975), (CU2[0], 1.06, 548, 978), (CU2[1], 1.0, 540, 960), (DUR, 1.06, 550, 950)]
PRS, HOV = (26, 25), (125, 30)                         # wrist offset from the dome when the palm is on it; and how far back the hand waits
SWI = (604, 1456)                                     # the pump switch on the sill
BTN = (112, 1090)                                     # the release button on its post beside her


def fall_u(t):
    return 0.0 if t < T_REL else min(1.0, (t - T_REL) / (T_LAND - T_REL)) ** 2


def window(c, t):
    """the control room window she watches through: thick bolted frame, glass glare, a sill with indicator lamps"""
    for x0 in (120, 380): c.drawPath(poly([(x0, 300), (x0 + (180 if x0 < 200 else 60), 300), (x0 - 80, 1440), (x0 - 260 + (0 if x0 < 200 else 110), 1440)]), skia.Paint(AntiAlias=True, Color=C((200, 225, 255), 20), BlendMode=A.SCREEN))
    for r in (skia.Rect(-400, -400, 54, 2400), skia.Rect(1026, -400, 1480, 2400), skia.Rect(-400, -400, 1480, 446)): c.drawRect(r, P((14, 17, 34)))
    c.drawRect(skia.Rect(54, 446, 66, 1432), P((96, 116, 164))); c.drawRect(skia.Rect(1014, 446, 1026, 1432), P((46, 58, 96))); c.drawRect(skia.Rect(54, 446, 1026, 458), P((96, 116, 164)))
    for i in range(9):
        for (bx, by) in ((27, 520 + i * 110), (1053, 520 + i * 110)): c.drawCircle(bx, by, 7, P((70, 84, 124))); c.drawCircle(bx - 1.5, by - 1.5, 3, P((150, 170, 210)))
    c.drawRect(skia.Rect(-400, 1432, 1480, 2400), P((14, 17, 34))); c.drawRect(skia.Rect(-400, 1432, 1480, 1444), P((96, 116, 164)))
    c.drawPath(poly([(-400, 1444), (1480, 1444), (1480, 1500), (-400, 1500)]), P((26, 31, 58)))                 # the console desk under the window
    for k, x0 in enumerate((560, 800)):                        # small screens with live traces
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x0, 1660, x0 + 210, 1800), 12, 12), P((10, 26, 40))); c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x0, 1660, x0 + 210, 1800), 12, 12), SP((70, 90, 140), 4))
        tr = skia.Path(); tr.moveTo(x0 + 12, 1730)
        for j in range(1, 20): tr.lineTo(x0 + 12 + j * 9.8, 1730 + 34 * math.sin(j * 0.9 + t * (2 + k)) * math.sin(j * 0.31 + k))
        c.drawPath(tr, SP((90, 230, 200) if k == 0 else (255, 200, 90), 4))
    for i in range(10): c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(560 + i * 46, 1840, 592 + i * 46, 1872), 6, 6), P([(60, 76, 120), (80, 96, 150)][i % 2]))
    fl = smooth((t - T_PUMPS + 0.42) / 0.1)                    # the pump switch: a toggle she flips
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(SWI[0] - 34, SWI[1] - 15, SWI[0] + 34, SWI[1] + 15), 9, 9), P((60, 72, 112))); c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(SWI[0] - 34, SWI[1] - 15, SWI[0] + 34, SWI[1] + 15), 9, 9), SP((120, 140, 190), 3))
    lx = SWI[0] + lerp(-18, 18, fl); c.drawLine(SWI[0], SWI[1] + 2, lx, SWI[1] - 26, SP((200, 210, 230), 9)); c.drawCircle(lx, SWI[1] - 28, 9, P(mix((230, 90, 90), (90, 230, 150), fl)))
    for i in range(9):                                         # console lamps along the sill
        on = math.sin(t * (1.3 + 0.37 * i) + i * 2.1) > -0.3
        c.drawCircle(690 + i * 40, 1466, 6, P([(90, 230, 150), (255, 190, 80), (120, 190, 255)][i % 3], 255 if on else 70))


def button(c, press, lit):
    """the release button: a big red push button on a panel bolted to the window frame at her left, at chest height"""
    x, y = BTN
    box = skia.RRect.MakeRectXY(skia.Rect(x - 84, y - 96, x + 84, y + 96), 16, 16)
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x - 80, y - 88, x + 92, y + 104), 16, 16), P((0, 0, 0), 110, MaskFilter=blur(10)))
    c.drawRRect(box, P((240, 196, 70))); c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x - 84, y - 96, x + 84, y - 84), 8, 8), P((255, 232, 150)))
    for k in range(-4, 5): c.drawLine(x + k * 20 - 8, y + 94, x + k * 20 + 8, y + 72, SP((40, 36, 40), 6))
    for (dx, dy) in ((-66, -78), (66, -78)): c.drawCircle(x + dx, y + dy, 6, P((150, 110, 40)))
    r = 50 - 11 * press                                        # pushed in, the dome sinks into its collar
    c.drawCircle(x, y, 62, P((60, 20, 30))); c.drawCircle(x, y, 56, P((120, 30, 40))); c.drawCircle(x, y - 6 + 6 * press, r, P(mix((214, 50, 60), (255, 130, 110), lit))); c.drawCircle(x - 8 + 4 * press, y - 16 + 9 * press, r * 0.6, P(mix((240, 96, 96), (255, 210, 190), lit), 200))
    if lit > 0.02: A.glow(c, x, y - 6, 150, (255, 120, 100), 130 * lit)


def replay(c, t):
    """the control room monitor, full frame: a replay of the earlier test with air in the chamber. The same ball and feather, really dropped."""
    u = (t - T_IN) / (T_BUT - T_IN)
    c.save(); z = 1.0 + 0.04 * u; c.translate(540, 960); c.scale(z, z); c.translate(-790, -925 - 10 * u)
    t0 = T_WINS - 0.7; gu = min(1.0, max(0.0, (t - t0) / 0.7)) ** 2
    dn = smooth((t - T_WINS) / 0.07) * (1 - 0.4 * smooth((t - T_WINS - 0.08) / 0.3)) if t >= T_WINS else 0.0
    D.chamber(c, t + 9, 0.0); D.pad(c, dn, 0.0); D.air(c, t, 1.0, None); D.rig(c, t, smooth((t - t0) / 0.1))
    sw0 = 2.2 * math.sin(t * 1.3) if t < t0 else 0.0
    bsq = 1 - 0.05 * dn
    c.save(); c.translate(D.BX + sw0, D.Y0 + H * gu); c.scale(1 / bsq, bsq); D.ball(c, 0, 0); c.restore()
    TL_ = T_BUT - 1.0; fk = max(0.0, t - t0); fu = min(1.0, fk / (TL_ - t0)); sw_ = 1 - smooth((fu - 0.92) / 0.08)
    if t < TL_: D.feather(c, D.FX + sw0 * 0.6 + 58 * math.sin(fk * 3.3) * sw_ * min(1.0, fk * 3), FY + H * fu ** 1.1, rot=sw0 * 0.5 + 28 * math.sin(fk * 3.3 + 1.3) * sw_ * min(1.0, fk * 3))
    else:                                                       # in air too it cannot stand on its quill: it tips over, slowly, and lies flat
        th = -84 * min(1.0, ((t - TL_) / 0.7)) ** 1.6 + (3 * math.sin((t - TL_ - 0.7) * 12) * math.exp(-(t - TL_ - 0.7) * 6) if t > TL_ + 0.7 else 0.0)
        D.feather(c, D.FX + 156 * math.sin(math.radians(th)), FY + H + 156 - 156 * math.cos(math.radians(th)), rot=th)
    pass   # the air holds it up: it rocks and drifts all the way down
    c.restore()
    c.drawRect(skia.Rect(0, 0, 1080, 1920), skia.Paint(Color=C((110, 190, 255), 20), BlendMode=A.SCREEN))
    for y in range(0, 1920, 8): c.drawRect(skia.Rect(0, y, 1080, y + 2), P((0, 10, 30), 26))
    bz = skia.Path(); bz.addRect(skia.Rect(-10, -10, 1090, 1930)); bz.addRRect(skia.RRect.MakeRectXY(skia.Rect(34, 430, 1046, 1440), 34, 34)); bz.setFillType(skia.PathFillType.kEvenOdd)
    c.drawPath(bz, P((14, 17, 34))); c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(34, 430, 1046, 1440), 34, 34), SP((96, 116, 164), 8))
    A.tag(c, 'EARLIER TEST: WITH AIR', 540, 484, Wt, 54, pop(t, T_IN), 1.0)
    if math.sin(t * 6) > 0: c.drawCircle(96, 574, 14, P((255, 90, 90)))
    f = skia.Font(L.BLACK, 40); c.drawString('REPLAY', 126, 588, f, P((255, 255, 255), 230))


def scene(c, t):
    for i, (a, b) in enumerate((CU1, CU2)):                    # her face
        if a <= t < b:
            u = (t - a) / (b - a)
            c.save(); z = 1.0 + 0.06 * u; c.translate(540, 950); c.scale(z, z); c.translate(-540, -900)
            D.face_bg(c, t, KEYL, 1)
            lid = 0.05 if 0.46 < u < 0.5 else 1.0
            if i == 0: CH.face(c, t, look=0.2 + 0.5 * math.sin(u * 7.0), looky=-0.8, brow=0.5 + 0.4 * smooth((u - 0.3) / 0.2), worry=0.25, smile=-0.05, lid=lid, key=KEYL, key_side=1, tilt=5 * smooth((u - 0.3) / 0.3))
            else:
                k = smooth(u / 0.35)
                CH.face(c, t, look=lerp(0.4, 0.0, k), looky=lerp(0.6, 0.0, k), brow=1.0, lid=1.15 if lid > 0.5 else lid, smile=lerp(0.2, 0.95, k), opn=lerp(0.5, 0.7, k), key=KEYL, key_side=1)
            c.restore(); return
    if T_IN - 0.05 <= t < T_BUT - 0.05: replay(c, t); return
    z, tx, ty = keys(CAM, t)
    z += 0.005 * math.sin(t * 0.7); tx += 3 * math.sin(t * 0.41); ty += 3 * math.cos(t * 0.33)
    c.save(); c.translate(540, 960); c.scale(z, z); c.translate(-tx, -ty)
    pump = smooth((t - T_PUMPS + 0.4) / 0.4) * (1 - smooth((t - T_AIR2 - 0.5) / 0.6))
    vac = smooth((t - T_PUMPS) / (T_AIR2 + 0.3 - T_PUMPS))
    D.chamber(c, t, vac); D.vents(c, t, pump)
    fu = fall_u(t); dy = H * fu
    low = -100 * (1 - ease_io(t / 1.3))                       # frame zero: the rig is still lowering them into place
    sway = (2.2 + 12 * math.exp(-t * 0.9)) * math.sin(t * 2.4) * (1 - smooth((t - T_REL + 1.0) / 0.8))      # still swinging from being lowered in, then settling
    landed = t >= T_LAND
    dent = (1.0 - 0.35 * smooth((t - T_LAND - 0.08) / 0.3)) * smooth((t - T_LAND + 0.03) / 0.07) if t >= T_LAND - 0.03 else 0.0
    D.pad(c, dent, 0.0)
    D.air(c, t, 1.0, (t - T_PUMPS + 0.3) if t >= T_PUMPS - 0.3 else None)
    c.save(); c.translate(0, low)
    D.rig(c, t, smooth((t - T_REL) / 0.1))
    c.restore()
    # the real ones
    bsq = 1 - 0.05 * dent
    c.save(); c.translate(D.BX + sway, D.Y0 + low + dy); c.scale(1 / bsq, bsq); D.ball(c, 0, 0, rot=0.0); c.restore()
    if not landed: D.feather(c, D.FX + sway * 0.6, FY + low + dy, rot=sway * 0.5)
    else:                                                       # it cannot balance on its tip: it tips over and lies flat on the pad
        th = -84 * min(1.0, ((t - T_LAND) / 0.55)) ** 2 + (4 * math.sin((t - T_LAND - 0.55) * 14) * math.exp(-(t - T_LAND - 0.55) * 7) if t > T_LAND + 0.55 else 0.0)
        bx_, by_ = D.FX, FY + H + 156
        D.feather(c, bx_ + 156 * math.sin(math.radians(th)), by_ - 156 * math.cos(math.radians(th)), rot=th)
    # pull, mass, equal acceleration
    if T_GRAV <= t < T_SO + 0.2:
        out = 1 - smooth((t - T_SO + 0.1) / 0.3)
        eq = smooth((t - T_CANCEL) / 0.5)
        g1 = smooth((t - T_GRAV - 0.2) / 0.35)
        yb = D.Y0 + D.BR + 18
        D.arrow(c, D.BX, yb, yb + lerp(250, 150, eq) * g1, mix((255, 110, 110), TEALC, eq), lerp(22, 16, eq), out)
        D.arrow(c, D.FX, yb, yb + lerp(60, 150, eq) * g1, mix((255, 110, 110), TEALC, eq), lerp(9, 16, eq), out)
        if t < T_CANCEL:
            out = out * (1 - smooth((t - T_CANCEL + 0.3) / 0.28))
            A.tag(c, 'BIG PULL', D.BX - 190, yb + 120, (255, 130, 130), 40, pop(t, T_GRAV + 0.3), out)
            A.tag(c, 'SMALL PULL', 872, yb + 130, (255, 130, 130), 34, pop(t, T_GRAV + 0.9), out)
            if t >= T_BUT2 + 0.6:
                A.tag(c, 'BIG MASS', D.BX - 190, yb + 190, Y, 40, pop(t, T_BUT2 + 0.6), out)
                A.tag(c, 'SMALL MASS', 872, yb + 192, Y, 34, pop(t, T_BUT2 + 1.4), out)
        else:
            A.tag(c, 'SAME ACCELERATION', 772, yb + 230, TEALC, 38, pop(t, T_CANCEL + 0.1), out)
    if 0 < fu and t < T_LAND + 0.9:                             # a level line through both bottoms: side by side all the way down
        yy = D.Y0 + D.BR + low + dy
        a = smooth((t - T_FALL + 0.2) / 0.3) * (1 - smooth((t - T_LAND - 0.5) / 0.4))
        c.drawLine(D.BX - 110, yy, D.FX + 90, yy, skia.Paint(AntiAlias=True, Color=C(TEALC, 230 * a), Style=skia.Paint.kStroke_Style, StrokeWidth=5, PathEffect=skia.DashPathEffect.Make([18, 14], 0)))
    window(c, t)
    press = (-0.12 * math.sin(math.pi * min(1.0, max(0.0, (t - T_REL + 0.42) / 0.22))) + 1.0 * smooth((t - T_REL + 0.2) / 0.16)) * (1 - smooth((t - T_REL - 0.5) / 0.35))     # a short wind up, then the push
    button(c, max(0.0, press), smooth((t - T_REL + 0.02) / 0.1) * (1 - smooth((t - T_LAND - 0.4) / 0.5)))
    # her, at the window
    yaw = keys([(0, 0.15), (1.2, 0.5), (2.6, 0.5), (3.3, -0.45), (4.3, -0.45), (5.0, 0.5), (T_IN, 0.5), (T_WINS + 0.2, 0.42), (T_BUT + 0.4, 0.4), (T_BUT + 1.1, 0.05), (T_BUT + 1.8, 0.1), (T_PUMPS - 0.95, 0.66), (T_PUMPS - 0.25, 0.66), (T_PUMPS + 0.5, -0.5), (T_AIR2, -0.45), (T_GRAV + 0.4, 0.28), (T_GRAV + 1.6, 0.28), (T_GRAV + 2.3, 0.68), (T_BUT2 + 0.6, 0.68), (T_BUT2 + 1.3, 0.28), (T_BUT2 + 2.3, 0.3), (T_BUT2 + 3.0, 0.68), (T_CANCEL + 0.5, 0.45), (T_SO, 0.45), (T_GO - 0.1, -0.55), (T_REL + 0.25, -0.5), (T_FALL + 0.2, 0.45), (T_LAND, 0.36), (DUR, 0.4)], t)[0]
    tilt = keys([(0, -4), (T_REL, -4), (T_LAND, 5), (DUR, 2)], t)[0]
    hl = hr = None; dyh = 0.0; sq = 1.0; grab = None; aim = None
    pu = ease_io((t - T_GRAV - 0.1) / 0.7) * (1 - ease_io((t - T_BUT2 + 0.5) / 0.7)); pu2 = ease_io((t - T_BUT2 - 2.2) / 0.6) * (1 - ease_io((t - T_CANCEL - 0.9) / 0.7))
    for (pk, tg_) in ((pu, (D.BX - 60, D.Y0 + 60)),):      # she points at the ball, later at the feather, as each is talked about
        if pk > 0.01:
            sx_, sy_ = CH.X0 + 106, CH.SHY + 14; r_ = CH.rest_hand(1); dd = math.hypot(tg_[0] - sx_, tg_[1] - sy_); hp_ = (sx_ + (tg_[0] - sx_) / dd * 205, sy_ + (tg_[1] - sy_) / dd * 205)
            a0_ = math.atan2(r_[1] - sy_, r_[0] - sx_); a1_ = math.atan2(hp_[1] - sy_, hp_[0] - sx_); rr_ = lerp(math.hypot(r_[0] - sx_, r_[1] - sy_), 205, pk); aa_ = lerp(a0_, a1_, pk)
            hr = (sx_ + rr_ * math.cos(aa_), sy_ + rr_ * math.sin(aa_)); aim = tg_ if pk > 0.6 else None
    cu = ease_io((t - T_PUMPS + 1.25) / 0.6) * (1 - ease_io((t - T_PUMPS + 0.15) / 0.65))        # her right hand goes to the pump switch, flips it, and comes back
    if cu > 0.01:
        r_ = CH.rest_hand(1); fl_ = smooth((t - T_PUMPS + 0.5) / 0.14); tg_ = (SWI[0] - 34 + 26 * fl_, SWI[1] - 86)
        hr = (lerp(r_[0], tg_[0], cu), lerp(r_[1], tg_[1], cu) - 26 * math.sin(math.pi * cu) * (1 if t < T_PUMPS - 0.5 else 0.4)); grab = (SWI[0] - 18 + 36 * fl_, SWI[1] - 28) if cu > 0.5 else None
    shift = 15 * math.sin(math.pi * min(1.0, max(0.0, (t - T_BUT - 0.5) / 1.5))) ** 2 * (-1) + 12 * cu
    rl, rr = CH.rest_hand(-1), CH.rest_hand(1); sxl, syl = CH.X0 - 106, CH.SHY + 14
    hov = (BTN[0] + PRS[0] + HOV[0] * (1 - press) + 2 * math.sin(t * 2.6) * (1 - press), BTN[1] + PRS[1] + HOV[1] * (1 - press) + 3 * math.sin(t * 2.6 + 1) * (1 - press))    # her left palm waits just off the button, then pushes onto it
    if t < CU2[0]:
        up = ease_io((t - T_REL + 1.0) / 0.55) * (1 - ease_io((t - T_REL - 0.65) / 0.7))      # her arms hang at her sides until it is time
        a0 = math.atan2(rl[1] - syl, rl[0] - sxl); a1 = math.atan2(hov[1] - syl, hov[0] - sxl) + 2 * math.pi; r0 = math.hypot(rl[0] - sxl, rl[1] - syl); r1 = math.hypot(hov[0] - sxl, hov[1] - syl)
        if a1 - a0 > math.pi: a1 -= 2 * math.pi
        aa = lerp(a0, a1, up); rad = lerp(r0, r1, up)
        if up > 0.01: hl = (sxl + rad * math.cos(aa), syl + rad * math.sin(aa))
    k = t - CU2[1]
    if k > 0:                                                   # they landed together: both arms come up, elbows bent, and she bounces
        e = ease_io(k / 0.8)

        def arc(side, rest, tg):                               # each hand swings up round the outside of its shoulder
            sx, sy = CH.X0 + side * 106, CH.SHY + 14
            a0 = math.atan2(rest[1] - sy, rest[0] - sx); a1 = math.atan2(tg[1] - sy, tg[0] - sx)
            if side < 0 and a1 < a0: a1 += 2 * math.pi
            if side > 0 and a1 > a0: a1 -= 2 * math.pi
            aa = lerp(a0, a1, e); rad = lerp(math.hypot(rest[0] - sx, rest[1] - sy), math.hypot(tg[0] - sx, tg[1] - sy), min(1.0, e)) * (1 - 0.62 * math.sin(math.pi * e))     # elbows fold on the way up
            return (sx + rad * math.cos(aa), sy + rad * math.sin(aa))
        hl = arc(-1, rl, (CH.X0 - 150, 1030)); hr = arc(1, rr, (CH.X0 + 118, 1016))
        if 0.25 < k < 3.0:
            ph = ((k - 0.25) % 0.55) / 0.55; dyh = -38 * math.sin(math.pi * ph) * smooth((k - 0.25) / 0.2); sq = 1 - 0.03 * math.cos(2 * math.pi * ph)
            hl = (hl[0] - 10 * math.sin(math.pi * ph), hl[1] + dyh * 0.9); hr = (hr[0] + 10 * math.sin(math.pi * ph), hr[1] + dyh * 0.9)       # two fists pump with each bounce
    CH.back(c, t, yaw=yaw, tilt=tilt, hl=hl, hr=hr, dy=dyh + 2.5 * math.sin(t * 1.1), sq=sq, grab=grab, sway=6 * math.sin(t * 0.5) + 2 * math.sin(t * 0.83) + 16 * (yaw - 0.4) + shift, pr=aim, rim_boost=0.6, rimcol=KEYL)
    c.restore()
    # gauge and slow motion chip (screen space)
    if T_PUMPS - 0.2 <= t < T_GRAV:
        a = smooth((t - T_PUMPS + 0.2) / 0.25) * (1 - smooth((t - T_GRAV + 0.3) / 0.3))
        pct = lerp(100, 0, smooth((t - T_PUMPS) / (T_AIR2 + 0.2 - T_PUMPS)))
        A.tag(c, ('AIR %d%%' % round(pct)) if pct >= 1 else 'ALMOST NO AIR', 262, 520, mix(Wt, TEALC, 1 - pct / 100), 52, 1.0, a)
    if T_REL - 0.2 <= t < T_LAND + 0.5:
        A.tag(c, 'SLOW MOTION', 250, 520, Wt, 48, 1.0, smooth((t - T_REL + 0.2) / 0.2) * (1 - smooth((t - T_LAND - 0.2) / 0.3)))


TITLES = [
    (0.0, [[('BOWLING BALL VS ', Wt), ('FEATHER', Y)], [('WHICH LANDS ', Wt), ('FIRST?', Y)]]),
    (T_IN, [[('WITH AIR IN THE ROOM', Wt)], [('THE ', Wt), ('BALL', R), (' WINS EASILY', Wt)]]),
    (T_BUT, [[('THIS ROOM IS A GIANT', Wt)], [('VACUUM CHAMBER', TL)]]),
    (T_PUMPS, [[('THE PUMPS PULL OUT', Wt)], [('ALMOST ALL THE ', Wt), ('AIR', TL)]]),
    (T_GRAV, [[('GRAVITY PULLS ', Wt), ('HARDER', R)], [('ON THE HEAVY BALL', Wt)]]),
    (T_BUT2, [[('BUT THE BALL IS ALSO', Wt)], [('HARDER TO ', Wt), ('SPEED UP', Y)]]),
    (T_THOSE, [[('THE TWO', Wt)], [('CANCEL EXACTLY', TL)]]),
    (T_SO, [[('SHE HITS THE BUTTON', Wt)], [('THE CLAMPS ', Wt), ('LET GO', Y)]]),
    (T_FALL, [[('SIDE BY SIDE', TL)], [('ALL THE WAY DOWN', Wt)]]),
    (T_TOG, [[('THEY LAND', Wt)], [('TOGETHER', Y)]]),
    (T_WITH, [[('NO AIR', TL)], [('EVERYTHING FALLS THE SAME', Wt)]]),
]

Short.wm_shift = 0
SHORT = Short(WD, 'AP PHYSICS 1', TITLES, scene, DUR, T_END, lift=lambda t: 1.04, fix={'TOGETHER': 'together'})

SHORT.wm_shift = 742                                  # the corner tag sits at the right on this one, clear of her arm and the button

if __name__ == '__main__':
    out, st = kit.args()
    kit.render(SHORT, out, stills=st, outdir=os.environ.get('STILLS', '/home/claude/w1124/drop/out/stills'))
