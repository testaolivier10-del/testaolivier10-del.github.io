import requests, sys
K=open('/root/.lpkey/k').read().strip()
plan = {
 "positive_global_styles": ["cinematic science documentary score", "soft synth pads", "felt piano", "pulsing strings", "wonder and suspense", "restrained", "high quality mix"],
 "negative_global_styles": ["vocals", "lyrics", "drum kit", "EDM", "trap beat", "comedy", "lo-fi", "trailer brass", "horror stingers"],
 "sections": [
  {"section_name": "the question", "positive_local_styles": ["expectant pulse", "single piano notes", "a question hanging", "A minor"], "negative_local_styles": ["drums"], "duration_ms": 8000, "lines": []},
  {"section_name": "in ordinary air", "positive_local_styles": ["light and matter of fact", "plucked strings"], "negative_local_styles": ["drums"], "duration_ms": 5700, "lines": []},
  {"section_name": "the air is pumped out", "positive_local_styles": ["sound thins out", "airy high pad", "growing stillness"], "negative_local_styles": ["drums"], "duration_ms": 6200, "lines": []},
  {"section_name": "pull and mass", "positive_local_styles": ["steady thoughtful pulse", "low strings", "building"], "negative_local_styles": ["drums"], "duration_ms": 8000, "lines": []},
  {"section_name": "the fall", "positive_local_styles": ["near silence, one held high note", "suspended", "then a warm full chord arrives"], "negative_local_styles": ["drums"], "duration_ms": 5100, "lines": []},
  {"section_name": "together", "positive_local_styles": ["wonder", "warm strings and piano", "resolves to A major, final chord held"], "negative_local_styles": [], "duration_ms": 4700, "lines": []}
 ]
}
r = requests.post('https://api.elevenlabs.io/v1/music?output_format=mp3_44100_192', headers={'xi-api-key': K}, json={'composition_plan': plan, 'model_id': 'music_v1'}, timeout=600)
print(r.status_code, r.text[:300] if r.status_code != 200 else len(r.content))
if r.status_code == 200: open(sys.argv[1], 'wb').write(r.content)
