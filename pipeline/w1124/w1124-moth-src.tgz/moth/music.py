import requests, sys
K=open('/root/.lpkey/k').read().strip()
plan = {
 "positive_global_styles": ["cinematic nature documentary score", "pizzicato strings", "clarinet", "felt piano", "curious and light", "restrained", "high quality mix"],
 "negative_global_styles": ["vocals", "lyrics", "drum kit", "EDM", "trap beat", "comedy", "lo-fi", "trailer brass", "horror stingers"],
 "sections": [
  {"section_name": "the bird and the two moths", "positive_local_styles": ["playful pizzicato", "a question hanging", "light woodland morning", "G major"], "negative_local_styles": ["drums"], "duration_ms": 7000, "lines": []},
  {"section_name": "the catch", "positive_local_styles": ["quick string run then a soft accent", "curious clarinet"], "negative_local_styles": ["drums"], "duration_ms": 6000, "lines": []},
  {"section_name": "factories and soot", "positive_local_styles": ["turns to G minor", "low cello drone", "heavy slow pulse", "industrial gloom, quiet"], "negative_local_styles": ["drums"], "duration_ms": 3900, "lines": []},
  {"section_name": "the choice flips", "positive_local_styles": ["the pizzicato motif returns darker", "minor key", "quick run then a soft accent", "tender held note at the end"], "negative_local_styles": ["drums"], "duration_ms": 5400, "lines": []},
  {"section_name": "fifty years", "positive_local_styles": ["steady building ostinato", "time passing", "strings layering"], "negative_local_styles": ["drums"], "duration_ms": 4700, "lines": []},
  {"section_name": "natural selection", "positive_local_styles": ["calm resolution", "warm strings and piano", "a clear final chord in G major, held"], "negative_local_styles": [], "duration_ms": 7600, "lines": []}
 ]
}
r = requests.post('https://api.elevenlabs.io/v1/music?output_format=mp3_44100_192', headers={'xi-api-key': K}, json={'composition_plan': plan, 'model_id': 'music_v1'}, timeout=600)
print(r.status_code, r.text[:300] if r.status_code != 200 else len(r.content))
if r.status_code == 200: open(sys.argv[1], 'wb').write(r.content)
