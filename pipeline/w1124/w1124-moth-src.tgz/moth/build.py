"""w1124-01-peppered-moth (AP Biology, natural selection, CED 7.1 and 7.2). 1080x1920, 30 fps, all code, no people. Round 2.
Logline: a hungry bird picks the moth it can see, and when soot turns the trees black its choice flips, so the dark moths take over the city.
Every hunt is acted out: the bird crouches, pushes off, flies an arc, hovers while its beak closes on the moth, carries it back at its real
size with the wings folded, flares and lands, swallows, and turns with a hop. No moth leaves the bark unless the bird takes it, and no moth
changes colour. Accuracy as in round 1 (Manchester 1848, about 98 percent dark by 1895; soot darkens bark and kills lichen)."""
import sys, math, os
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/moth', '/home/claude/w1124/lib']
import mart as M
import numpy as np, skia
import kit, lpk, art as A
from kit import Words, Short, ease_io, Wt, Y, R, TL
from lpk import P, SP, C, blur, smooth, lerp, mix

WD = Words('/home/claude/w1124/moth/out/words.json'); at = WD.at
T_Q, T_CLEAN, T_STANDS, T_EATEN = at('which'), at('clean'), at('stands'), at('eaten')
T_FACT, T_SOOT, T_NOW, T_TARGET = at('then'), at('soot'), at('now'), at('target')
T_ONES, T_EGGS, T_FIFTY, T_NEARLY = at('ones'), at('eggs'), at('fifty'), at('nearly')
T_NOBODY, T_BIRDS, T_NAT, T_DARK3 = at('nobody'), at('birds'), at('natural'), at('dark', 3)
T_END = WD.end() + 0.35; DUR = T_END + 1.5
BS, MS = 1.45, 0.62                                   # bird and moth sizes: a great tit is about 14 cm, a peppered moth about 5 cm across
PALE_AT, DARK_A, DARK_B = (790, 900, -14), (560, 1200, 12), (700, 1180, 8)
PALE_POP = [(790, 720, -20), (610, 1272, 16)]
GOLD = (255, 214, 90)
BX, BY = M.PERCH[0], M.PERCH[1] + 20
BODY = (BX + 6, BY - 96)                              # where the perched bird's body is: flights start and end here
# the hunts: (leaves the branch at, target, dark, fast)
HUNTS = [(T_EATEN - 0.25, DARK_A, 1.0, False), (T_TARGET + 0.3, PALE_AT, 0.0, False), (T_FIFTY + 0.9, PALE_POP[0], 0.0, True), (T_BIRDS - 0.9, PALE_POP[1], 0.0, False)]


def keys(ks, t):
    if t <= ks[0][0]: return ks[0][1:]
    for a, b in zip(ks, ks[1:]):
        if a[0] <= t < b[0]:
            u = ease_io((t - a[0]) / (b[0] - a[0])); return tuple(lerp(x, y, u) for x, y in zip(a[1:], b[1:]))
    return ks[-1][1:]


CAM = [(0, 1.0, 540, 960), (T_Q - 0.9, 1.03, 545, 965), (T_Q + 0.6, 1.3, 660, 1045), (T_Q + 1.5, 1.3, 668, 1050), (T_CLEAN + 0.6, 1.07, 545, 985), (T_EATEN - 0.2, 1.15, 500, 1010), (T_EATEN + 1.6, 1.08, 500, 980), (T_FACT + 1.4, 1.16, 380, 1030),
       (T_SOOT + 0.6, 1.06, 450, 1000), (T_NOW + 0.9, 1.12, 560, 960), (T_TARGET + 1.9, 1.1, 520, 980), (T_ONES + 0.9, 2.15, 704, 1232), (T_FIFTY - 0.15, 2.28, 708, 1242),
       (T_FIFTY + 0.8, 1.0, 600, 1000), (T_NOBODY, 1.03, 600, 1005), (T_BIRDS + 1.4, 1.1, 560, 990), (T_NAT + 0.4, 1.26, 450, 900), (DUR, 1.4, 412, 862)]


def soot_at(t):
    return smooth((t - T_FACT - 0.5) / (T_NOW - T_FACT - 0.3))


def _arc(p, q, lift, u):
    return lerp(p[0], q[0], u), lerp(p[1], q[1], u) - lift * math.sin(math.pi * u)


def _lean(p, q, lift, u):
    x0, y0 = _arc(p, q, lift, u); x1, y1 = _arc(p, q, lift, min(1.0, u + 0.04))
    return max(-30.0, min(30.0, math.degrees(math.atan2(y1 - y0, abs(x1 - x0) + 1e-3))))


def fly_tip(x, y, ang, left):
    a = math.radians(ang); lx, ly = 120 * BS, -8 * BS
    dx, dy = lx * math.cos(a) - ly * math.sin(a), lx * math.sin(a) + ly * math.cos(a)
    return (x - dx if left else x + dx, y + dy)


def perch_tip(look, crouch, face, bob=0.0):
    lk = math.radians(look); r = math.radians(-8 + crouch * 16)
    lx = 46 + 60 * math.cos(lk) - 2 * math.sin(lk); ly = -116 + 60 * math.sin(lk) + 2 * math.cos(lk)
    x = lx * math.cos(r) - ly * math.sin(r); y = lx * math.sin(r) + ly * math.cos(r) + crouch * 16
    return (BX + face * x * BS, BY + bob + y * BS)


def perch_head(crouch, face, bob=0.0):
    r = math.radians(-8 + crouch * 16); lx, ly = 46, -116
    return (BX + face * (lx * math.cos(r) - ly * math.sin(r)) * BS, BY + bob + (lx * math.sin(r) + ly * math.cos(r) + crouch * 16) * BS)


def hunt(t, h):
    """one hunt as a dict, or None. Phases: crouch, push off, out, hover and take, back, flare, land, hold, swallow, hop and turn."""
    t0, tg, dark, fast = h
    To, Th, Tb, Tl, Tk, Tg, Tt = (0.30, 0.14, 0.36, 0.15, 0.1, 0.34, 0.34) if fast else (0.42, 0.2, 0.5, 0.2, 0.3, 0.7, 0.46)
    td = t - t0
    if td < -0.28 or td > 0.3 + To + Th + Tb + Tl + Tk + Tg + Tt: return None
    G = (tg[0] - 120 * BS - 10, tg[1] - 6)                      # hovering here its beak tip is on the moth
    fl = math.sin(td * 2 * math.pi * 7.5 + math.pi / 4)
    d = dict(dark=dark, tg=tg, moth_on_bark=True, prey=None, prey_behind=False)
    if td < 0: d.update(mode='perch', face=1.0, crouch=smooth((td + 0.28) / 0.2), look=24); return d
    if td < 0.1:                                               # push off: legs straighten, wings snap up, the body tips nose up
        u = td / 0.1; d.update(mode='fly', left=False, x=BODY[0] + 10 * u, y=BODY[1] - 26 * u, ang=lerp(-6, -26, u), flap=lerp(0.2, 1.0, u), legs=1 - u); return d
    td -= 0.1; S = (BODY[0] + 10, BODY[1] - 26)
    if td < To:
        u = ease_io(td / To); x, y = _arc(S, G, 90, u); d.update(mode='fly', left=False, x=x, y=y, ang=lerp(-26, _lean(S, G, 90, u), smooth(u * 4)), flap=fl, legs=0); return d
    td -= To
    if td < Th:                                                # hover: the beak closes on the moth, the moth folds its wings as it is lifted off
        k = smooth((td - Th * 0.35) / (Th * 0.5)); x, y = G[0], G[1] + 5 * math.sin(td * 26)
        d.update(mode='fly', left=False, x=x, y=y, ang=10, flap=fl, legs=0.3, beak=1 - k)
        if k > 0: d['moth_on_bark'] = False; tip = fly_tip(x, y, 10, False); d['prey'] = (lerp(tg[0], tip[0], k), lerp(tg[1], tip[1], k), lerp(tg[2], 96, k), k)
        return d
    td -= Th; d['moth_on_bark'] = False; E = (BODY[0] + 8, BODY[1] - 30); G2 = (tg[0] + 120 * BS + 10, tg[1] - 6); Tr = 0.27
    if td < Tr:                                                # it banks round the moth it is holding: side on, front on with wings spread, side on the other way
        u = td / Tr; d['legs'] = 0.3
        if u < 0.3: d.update(mode='fly', left=False, x=lerp(G[0], tg[0] - 90, u / 0.3), y=G[1] - 10 * u, ang=lerp(10, -22, u / 0.3), flap=0.9, beak=0.5); tip = fly_tip(d['x'], d['y'], d['ang'], False)
        elif u < 0.7: d.update(mode='frontfly', x=tg[0] + lerp(-30, 30, (u - 0.3) / 0.4), y=tg[1] + 104 - 14 * math.sin(math.pi * (u - 0.3) / 0.4), wings=0.35 + 0.65 * abs(math.cos(math.pi * (u - 0.3) / 0.4))); tip = (d['x'], tg[1] - 74)
        else: d.update(mode='fly', left=True, x=lerp(tg[0] + 90, G2[0], (u - 0.7) / 0.3), y=G2[1] - 10 * (1 - u), ang=lerp(-22, 0, (u - 0.7) / 0.3), flap=0.9); tip = fly_tip(d['x'], d['y'], d['ang'], True)
        d['prey'] = (tip[0], tip[1], lerp(96, -96, smooth(u)), 1.0); return d
    td -= Tr; G = G2
    if td < Tb:
        u = ease_io(td / Tb); x, y = _arc(G, E, 150, u); fla = smooth((u - 0.72) / 0.28)           # flare: nose up, wings held high, legs reach for the branch
        ang = lerp(_lean(G, E, 150, u), -30, fla)
        d.update(mode='fly', left=True, x=x, y=y, ang=ang, flap=lerp(fl, 0.9, fla), legs=fla); tip = fly_tip(x, y, ang, True); d['prey'] = (tip[0], tip[1], -96, 1.0); return d
    td -= Tb
    if td < Tl + Tk:                                           # feet on the branch, it settles, the moth still in its beak
        cr = 0.7 * (1 - smooth(td / Tl)); d.update(mode='perch', face=-1.0, crouch=cr, look=6, beak=0.5, wingopen=0.85 * (1 - smooth(td / 0.16))); tip = perch_tip(6, cr, -1.0); d['prey'] = (tip[0], tip[1], -96, 1.0); return d
    td -= Tl + Tk
    if td < Tg:                                                # swallow: the head tosses back, the moth slides down behind the beak, a gulp follows
        u = td / Tg; toss = smooth(u / 0.35) * (1 - smooth((u - 0.75) / 0.25)); gulp = math.sin(math.pi * min(1.0, max(0.0, (u - 0.5) / 0.3))) if u > 0.5 else 0.0
        lk = -38 * toss + 8 * gulp; go = smooth((u - 0.12) / 0.45)
        tip = perch_tip(lk, 0, -1.0); hd = perch_head(0, -1.0)
        d.update(mode='perch', face=-1.0, crouch=0.12 * gulp, look=lk, beak=0.7 * (1 - smooth((u - 0.4) / 0.2)), prey_behind=True)
        d['prey'] = (lerp(tip[0], hd[0], go), lerp(tip[1], hd[1], go), -96, 1.0, 1 - 0.5 * go, 1 - smooth((go - 0.55) / 0.45))
        return d
    td -= Tg
    u = td / Tt; hop = -34 * math.sin(math.pi * u)             # it hops round to face the trunk again: side on, front on at the top of the hop, side on
    if u < 0.2: d.update(mode='perch', face=-1.0, crouch=0.5 * (1 - u / 0.2), look=10, bob=hop)
    elif u < 0.34: d.update(mode='perch', face=-0.55, crouch=0.0, look=10, bob=hop)
    elif u < 0.66: d.update(mode='front', bob=hop, wings=math.sin(math.pi * (u - 0.34) / 0.32))
    elif u < 0.8: d.update(mode='perch', face=0.55, crouch=0.0, look=10, bob=hop)
    else: d.update(mode='perch', face=1.0, crouch=0.5 * (u - 0.8) / 0.2, look=10, bob=hop)
    return d


# fifty years: two pale moths (both taken, on screen) and dark ones that keep fluttering in
_RS = np.random.default_rng(9)
DARK_SPOTS = [(520, 420), (640, 330), (560, 680), (760, 780), (880, 940), (520, 930), (650, 1030), (860, 1330), (500, 1160), (700, 1470), (840, 1130)]
DARK_POP = [(x, y, _RS.uniform(-30, 30), T_FIFTY + 0.15 + (T_NOBODY - T_FIFTY - 1.3) * i / len(DARK_SPOTS), [0.3, -0.4, 2.8, 3.5, 0.0, -0.8][i % 6]) for i, (x, y) in enumerate(DARK_SPOTS)]


def flutter_in(c, t, x, y, rot, dark, t_in, ang0, s, dur=1.0, dist=900):
    """a moth flies in from outside the frame, beating its wings on a wandering path, and settles flat on the bark"""
    if t < t_in: return
    u = smooth((t - t_in) / dur); w = 1 - u
    px = x + dist * w * math.cos(ang0) + 34 * w * math.sin(t * 11); py = y + dist * w * math.sin(ang0) * 0.7 - 160 * w * w + 30 * w * math.sin(t * 8 + 1)
    M.moth(c, px, py, s * (1 + 0.45 * min(1.0, w * 3)), rot + 50 * w * math.sin(t * 6 + x), dark, 1.0, t=t, flut=17.5 * min(1.0, w * 5) + (2.5 if abs(math.sin(t * 0.9 + x)) > 0.955 else 0.0))


T_LAY0, T_LAY1 = T_ONES + 0.55, T_FIFTY - 0.45
NEGG = 7
EGG_L = [(-30, 104), (-10, 109), (10, 109), (30, 104), (-20, 128), (0, 132), (20, 128)]       # the clutch, in the moth's own frame: two rows just behind her


def lay_u(t):
    return min(1.0, max(0.0, (t - T_LAY0) / (T_LAY1 - T_LAY0)))


def _l2w(lx, ly):
    r = math.radians(DARK_B[2]); return (DARK_B[0] + MS * (lx * math.cos(r) - ly * math.sin(r)), DARK_B[1] + MS * (lx * math.sin(r) + ly * math.cos(r)))


def lay_state(t):
    """she stays where she is; the tip of her abdomen reaches out past her wings, swings to the next place in the clutch, presses down,
    leaves an egg and lifts. Returns (abdomen tip in her frame or None, press 0..1, eggs laid so far as a float)"""
    g = smooth((t - T_LAY0 + 0.35) / 0.35) * (1 - smooth((t - T_LAY1 - 0.05) / 0.35))
    if g <= 0.01: return None, 0.0, (0.0 if t < T_LAY0 else float(NEGG))
    u = lay_u(t); k = min(NEGG - 1, int(u * NEGG)); f = u * NEGG - k if u < 1 else 1.0
    prev = EGG_L[k - 1] if k > 0 else (0, 92); cur = EGG_L[k]
    m = smooth(f / 0.4); press = math.sin(math.pi * min(1.0, max(0.0, (f - 0.3) / 0.6))) if 0 < u < 1 else 0.0
    tx, ty = lerp(prev[0], cur[0], m), lerp(prev[1], cur[1], m) - 11 * (1 - press) * (1 if u < 1 else 0)
    if u >= 1: tx, ty = EGG_L[-1][0], EGG_L[-1][1] - 11
    done = k + smooth((f - 0.5) / 0.14) if u < 1 else float(NEGG)
    return (lerp(0, tx, g), lerp(66, ty, g)), press, done


def eggs(c, t):
    """her eggs: pale green ovals pressed into a crack of the bark in a tight clutch, each where the tip of her abdomen has just been"""
    a = 1 - smooth((t - T_FIFTY - 0.1) / 0.5)
    if t < T_LAY0 - 0.6 or a <= 0.01: return
    cx, cy = _l2w(0, 118); ca = a * smooth((t - T_LAY0 + 0.6) / 0.3)
    cr = skia.Path(); p0 = _l2w(-78, 100); p1 = _l2w(-30, 122); p2 = _l2w(34, 112); p3 = _l2w(86, 134)
    cr.moveTo(*p0); cr.cubicTo(*p1, *p2, *p3)
    c.drawPath(cr, SP((30, 26, 34), 13, 170 * ca)); c.drawPath(cr, SP((12, 10, 16), 6, 210 * ca))
    c.drawOval(skia.Rect(cx - 34, cy - 20, cx + 34, cy + 22), P((14, 12, 18), 150 * ca, MaskFilter=blur(7)))
    done = lay_state(t)[2]
    for k in range(NEGG):
        ka = min(1.0, max(0.0, done - k)) * a
        if ka <= 0.01: continue
        x, y = _l2w(*EGG_L[k])
        c.save(); c.translate(x, y); c.rotate(DARK_B[2] + (-12, -4, 4, 12, -8, 0, 8)[k]); s_ = 0.55 + 0.45 * ka
        c.drawOval(skia.Rect(-7.6 * s_, -9.6 * s_, 7.6 * s_, 9.6 * s_), P((70, 112, 76), 255 * ka)); c.drawOval(skia.Rect(-6.1 * s_, -8.1 * s_, 6.1 * s_, 8.1 * s_), P((186, 226, 160), 255 * ka))
        c.drawOval(skia.Rect(-4.1 * s_, -6.3 * s_, 0.4 * s_, -1.2 * s_), P((242, 253, 230), 235 * ka)); c.restore()


LATE = [(600, 560, 14, T_BIRDS + 0.75, 2.9), (840, 640, -18, T_NAT - 0.75, -0.5), (610, 800, -8, T_NAT + 0.35, 3.3)]       # more dark moths keep arriving


def idle_turn(t):
    """the bird's turns while it waits at the end: (kind, face or wings, bob) ; None when it is simply perched facing the trunk"""
    def hopturn(u, a, b):
        hop = -34 * math.sin(math.pi * u)
        if u < 0.2: return ('perch', a, hop, 0.5 * (1 - u / 0.2))
        if u < 0.34: return ('perch', a * 0.55, hop, 0.0)
        if u < 0.66: return ('front', math.sin(math.pi * (u - 0.34) / 0.32), hop, 0.0)
        if u < 0.8: return ('perch', b * 0.55, hop, 0.0)
        return ('perch', b, hop, 0.5 * (u - 0.8) / 0.2)
    A2 = T_END + 0.5
    if t < A2: return None
    u = (t - A2) / 0.3                                          # the last move: a hop round to face us, a shake of the wings, and it stays looking out
    if u < 0.4: return ('perch', 1.0, -30 * math.sin(math.pi * u * 0.8), 0.5 * (1 - u / 0.4))
    if u < 0.7: return ('perch', 0.55, -30 * math.sin(math.pi * u * 0.8), 0.0)
    if u < 1.25: return ('front', 0.8 * max(0.0, 1 - (u - 0.7) / 0.5), -30 * math.sin(math.pi * min(1.0, u * 0.8)), 0.0)
    v = t - A2 - 0.375
    return ('front', 0.45 * abs(math.sin(v * 21)) if 0.25 < v < 0.62 else 0.0, 0.0, 0.0)


def scene(c, t):
    z, tx, ty = keys(CAM, t)
    z += 0.006 * math.sin(t * 0.7); tx += 3 * math.sin(t * 0.43); ty += 3 * math.cos(t * 0.37)
    soot = soot_at(t)
    c.save(); c.translate(540, 960); c.scale(z, z); c.translate(-tx, -ty)
    M.sky(c, t, soot); M.far_trees(c, t, soot); M.chimneys(c, t, soot, 0.22 + 0.78 * smooth((t - T_FACT + 0.2) / 0.7))     # the mills stay a faint shape in the haze until the story reaches them
    M.trunk(c, t, soot)
    sw = M.branch(c, t, soot)
    hs = [hunt(t, h) for h in HUNTS]; act = next((h for h in hs if h is not None), None)
    taken = [t > h[0] + 0.1 + (0.30 if h[3] else 0.42) + (0.14 if h[3] else 0.2) * 0.4 for h in HUNTS]      # (the turn after the catch does not change this)
    shiver = lambda ph: 1.0 if abs(math.sin(t * 0.9 + ph)) > 0.975 else 0.0
    # ---- moths on the bark (each stays exactly where it is until the bird's beak has it)
    if not taken[0]: M.moth(c, *DARK_A[:2], MS, DARK_A[2], 1.0, t=t, flut=shiver(0), ring=(max(smooth((t - 0.75) / 0.25) * (1 - smooth((t - 2.3) / 0.4)), smooth((t - T_STANDS + 0.5) / 0.3) * (1 - smooth((t - HUNTS[0][0]) / 0.3))), GOLD))
    if not taken[1]: M.moth(c, *PALE_AT[:2], MS, PALE_AT[2], 0.0, t=t, flut=shiver(1), ring=(max(smooth((t - 0.95) / 0.25) * (1 - smooth((t - 2.3) / 0.4)), smooth((t - T_NOW - 0.9) / 0.3) * (1 - smooth((t - HUNTS[1][0]) / 0.3))), GOLD))
    eggs(c, t)
    ls = (0.0, 0.0); ab, press, _n = lay_state(t); rim = smooth((t - T_ONES) / 0.5) * (1 - smooth((t - T_FIFTY) / 0.4))
    if rim > 0.01: A.glow(c, DARK_B[0] + ls[0], DARK_B[1] + ls[1], 210, (255, 214, 170), 70 * rim)          # warm light picks her out on the dark bark
    if ab is None: flutter_in(c, t, DARK_B[0], DARK_B[1], DARK_B[2], 1.0, T_SOOT - 1.7, -0.35, MS, dur=1.5, dist=760)
    else: M.moth(c, DARK_B[0], DARK_B[1] + 3.5 * press, MS, DARK_B[2] + 1.6 * math.sin(t * 9) * (0.3 + press), 1.0, 1.0, t=t, flut=1.2 + 5.0 * press, abd=ab)
    if t >= T_FIFTY - 0.3:
        for i, (x, y, r) in enumerate(PALE_POP):
            if not taken[2 + i]: flutter_in(c, t, x, y, r, 0.0, T_FIFTY - 0.25 + 0.1 * i, [-0.5, 0.5][i], MS, dur=0.85, dist=720)
        for (x, y, r, tin, ph) in DARK_POP + LATE: flutter_in(c, t, x, y, r, 1.0, tin, ph, MS * 0.92)
    # ---- the bird
    def prey_draw(d):
        p = d['prey']; M.moth(c, p[0], p[1], MS * (p[4] if len(p) > 4 else 1.0), p[2], d['dark'], p[5] if len(p) > 5 else 1.0, t=t, fold=p[3])
    blink = 0.0 if (t % 3.1) < 0.1 else 1.0
    if t < 0.62:                                                # frame zero: it is already swooping in; it flares and lands
        u = ease_io(t / 0.62); fla = smooth((u - 0.7) / 0.3)
        x, y = lerp(20, BODY[0], u), lerp(430, BODY[1] - 20, u) - 50 * math.sin(math.pi * u)
        M.tit_flying(c, x, y, lerp(20, -28, fla), lerp(math.sin(t * 2 * math.pi * 7.5 + math.pi / 4), 0.9, fla), s=BS, legs=fla)
    elif act is not None:
        if act['prey'] is not None and act['prey_behind']: prey_draw(act)
        if act['mode'] == 'fly':
            if act['left']: c.save(); c.translate(act['x'], act['y']); c.scale(-1, 1); M.tit_flying(c, 0, 0, act['ang'], act['flap'], s=BS, beak=0.5, legs=act['legs']); c.restore()
            else: M.tit_flying(c, act['x'], act['y'], act['ang'], act['flap'], s=BS, beak=act.get('beak', 0.0), legs=act['legs'])
        elif act['mode'] == 'front': M.tit_front(c, BX, BY + sw * 0.6 + act['bob'], BS, wings=act['wings'])
        elif act['mode'] == 'frontfly': M.tit_front(c, act['x'], act['y'], BS, wings=act['wings'], legs=False)
        else:
            M.tit_perched(c, BX, BY + sw * 0.6, t, s=BS, look=act['look'] + 2 * math.sin(t * 2.1), crouch=act['crouch'], blink=blink, beak=act.get('beak', 0.0), bob=act.get('bob', 0.0), face=act['face'], wingopen=act.get('wingopen', 0.0))
        if act['prey'] is not None and not act['prey_behind']: prey_draw(act)
    else:
        look_k = [(0.62, -6), (1.4, 10), (T_Q - 0.4, 10), (T_Q, 20), (T_Q + 0.5, 30), (T_Q + 1.0, 14), (T_CLEAN + 0.5, 22), (T_STANDS, 30), (T_FACT + 0.6, 6), (T_FACT + 1.4, -14), (T_SOOT, -8), (T_NOW, 14), (T_NOW + 0.8, 20),
                  (T_ONES + 1, 4), (T_FIFTY + 0.5, 20), (T_NOBODY + 0.6, 8), (T_BIRDS, 22), (T_NAT, -4), (T_NAT + 0.9, 16), (T_END + 0.3, 24), (T_END + 0.8, -10), (DUR, 4)]
        land = max(0.0, 1 - (t - 0.62) / 0.3) if t < 1.0 else 0.0
        hop = 0.0
        if 3.0 < t < 3.32: hop = -26 * math.sin(math.pi * (t - 3.0) / 0.32)
        it = idle_turn(t)
        lk = keys(look_k, t)[0] + 3 * math.sin(t * 2.1)
        if it is not None and it[0] == 'front': M.tit_front(c, BX, BY + sw * 0.6 + it[2], BS, wings=it[1])
        else:
            face, bob, cro = (1.0, hop, land * 0.8) if it is None else (it[1], it[2], it[3])
            if it is not None and it[1] == -1.0:               # facing away from the trunk it scans the other trees: quick looks up and along
                lk = keys([(T_BIRDS + 0.6, 8), (T_BIRDS + 0.8, 26), (T_BIRDS + 1.15, 26), (T_BIRDS + 1.3, -6), (T_BIRDS + 1.75, 6)], t)[0] + 3 * math.sin(t * 2.1)
            M.tit_perched(c, BX, BY + sw * 0.6, t, s=BS, look=lk, crouch=cro, blink=blink, bob=bob, tailup=land, face=face, wingopen=(0.85 * max(0.0, 1 - (t - 0.62) / 0.16) if t < 0.8 else 0.0) + (0.55 * abs(math.sin((t - T_NAT - 0.2) * 22)) if T_NAT + 0.2 < t < T_NAT + 0.63 else 0.0))
    M.canopy(c, t, soot); M.falling(c, t, soot)
    if T_FACT + 0.9 < t < T_NOW + 0.4:
        A.tag(c, 'MANCHESTER', 210, 1306, (255, 190, 120), 46, kit.ease_io((t - T_FACT - 0.9) / 0.25), 1 - smooth((t - T_NOW) / 0.4))
    c.restore()
    c.drawRect(skia.Rect(0, 0, 1080, 1920), P((30, 22, 30), 14 * soot))
    if T_FIFTY + 0.6 <= t < T_NOBODY + 0.2:
        u = smooth((t - T_FIFTY - 0.6) / (T_DARK3 - 0.25 - T_FIFTY - 0.6)); yr = int(round(lerp(1848, 1895, u)))
        a = smooth((t - T_FIFTY - 0.6) / 0.25) * (1 - smooth((t - T_NOBODY + 0.1) / 0.3))
        A.tag(c, str(yr), 838, 476, Wt, 86, 1.0, a)
        if t >= T_DARK3 - 0.2: A.tag(c, '98% DARK', 820, 596, GOLD, 70, 0.9 + 0.1 * smooth((t - T_DARK3 + 0.2) / 0.2), a * smooth((t - T_DARK3 + 0.2) / 0.15))


TITLES = [
    (0.0, [[('PEPPERED MOTH', Wt)], [('WHICH ONE GETS ', Wt), ('EATEN?', Y)]]),
    (T_CLEAN, [[('ON PALE BARK', Wt)], [('THE ', Wt), ('DARK', Y), (' MOTH STANDS OUT', Wt)]]),
    (T_FACT, [[('THEN THE FACTORIES', Wt)], [('COVERED THE TREES IN ', Wt), ('SOOT', R)]]),
    (T_NOW, [[('NOW THE ', Wt), ('PALE', Y), (' MOTH', Wt)], [('WAS THE EASY TARGET', Wt)]]),
    (T_ONES, [[('THE DARK ONES', Wt)], [('LIVE TO ', Wt), ('LAY EGGS', TL)]]),
    (T_FIFTY, [[('IN ABOUT FIFTY YEARS', Wt)], [('NEARLY EVERY MOTH WAS ', Wt), ('DARK', Y)]]),
    (T_NOBODY, [[('NOBODY CHANGED THE MOTHS', Wt)], [('THE BIRDS KEPT ', Wt), ('CHOOSING', Y)]]),
    (T_NAT, [[('NATURAL', TL)], [('SELECTION', TL)]]),
]

SHORT = Short(WD, 'AP BIOLOGY', TITLES, scene, DUR, T_END, lift=lambda t: 1.0, fix={'SELECTION': 'selection'})

if __name__ == '__main__':
    out, st = kit.args()
    kit.render(SHORT, out, stills=st, outdir=os.environ.get('STILLS', '/home/claude/w1124/moth/out/stills'))
