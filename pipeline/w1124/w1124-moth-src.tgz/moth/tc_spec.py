SPEC = {"beats": [{"vo": open("/home/claude/w1124/moth/vo.txt").read().strip()}]}
