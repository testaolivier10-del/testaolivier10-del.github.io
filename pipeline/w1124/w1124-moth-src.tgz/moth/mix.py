import sys; sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/moth', '/home/claude/w1124/lib']
import build as B
import mixlib as X
D1, D2 = B.HUNTS[0][0], B.HUNTS[1][0]; GRAB = 0.1 + 0.42 + 0.12
OUT = '/home/claude/w1124/moth/out'
fx = [('cloth_real', 0.05, 0.7, 0.55, 0.3, 0.0),                 # wings as the bird swoops in to land
      ('cloth_real', D1 + 0.02, 0.8, 0.5, 0.25, 0.0),           # it leaves the branch
      (X.tick(), D1 + GRAB, 1.0, None, 0.03, 0.0),             # the beak closes on the dark moth
      ('cloth_real', D2 + 0.02, 0.8, 0.5, 0.25, 0.0),           # second flight
      (X.tick(), D2 + GRAB, 1.0, None, 0.03, 0.0)]             # the beak closes on the pale moth
amb = ('birds_real', [(0, 0), (0.5, 1), (B.T_FACT, 1), (B.T_NOW, 0.35), (B.T_NOBODY, 0.35), (B.DUR - 1.2, 0.7), (B.DUR, 0.2)])   # the wood goes quieter under the soot
secs = [(0, 7.0), (7.0, 13.0), (13.0, 16.9), (16.9, 22.3), (22.3, 27.0), (27.0, B.DUR)]
X.mix(OUT, '/home/claude/w1124/moth/snd/b.mp3', B.DUR, fx, amb, secs, [(0, 1.0), (B.T_FACT, 1.0), (B.T_NOW, 0.9), (B.T_NOBODY, 0.9), (B.T_NAT, 1.25), (B.DUR, 1.2)])
if '--encode' in sys.argv: X.encode(OUT)
