"""Art for w1124-01-peppered-moth: an oak wood by Manchester, the trunk (clean lichen bark to soot), the moths, a great tit.
House flat style: flat fills, one shade band, a rim on the lit side. Light comes from the upper left. World = screen at zoom 1."""
import sys, math
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/lib']
import numpy as np, skia
from lpk import P, SP, C, blur, smooth, lerp, mix, poly, smooth_closed
from art import shaded, diffp, tube, op, glow, SCREEN

_R = np.random.default_rng(21)
TX0, TX1 = 430, 930                      # hero trunk edges at mid height
PERCH = (236, 742)                       # where the bird's feet hold the branch


def trunk_path():
    L = [(TX0 - 60, -40), (TX0 - 24, 300), (TX0 + 6, 640), (TX0, 760), (TX0 - 4, 1100), (TX0 - 30, 1500), (TX0 - 90, 2000)]
    Rr = [(TX1 + 110, 2000), (TX1 + 40, 1500), (TX1 + 10, 1100), (TX1, 700), (TX1 + 20, 300), (TX1 + 60, -40)]
    p = skia.Path(); p.moveTo(*L[0])
    for q in L[1:]: p.lineTo(*q)
    for q in Rr: p.lineTo(*q)
    p.close(); return p


TRUNK = trunk_path()
FURROWS = []
for i in range(34):
    x = _R.uniform(TX0 - 20, TX1 + 20); y = _R.uniform(-60, 1800); ln = _R.uniform(160, 520); w = _R.uniform(5, 13)
    FURROWS.append((x, y, ln, w, _R.uniform(-14, 14), _R.uniform(-10, 10)))
PLATES = [(_R.uniform(TX0, TX1), _R.uniform(0, 1900), _R.uniform(40, 110), _R.uniform(60, 180), _R.uniform(0.3, 1.0)) for _ in range(46)]
LICHEN = []
for i in range(30):
    cx = _R.uniform(TX0 + 20, TX1 - 10); cy = _R.uniform(120, 1700); r = _R.uniform(34, 92)
    n = 9; pts = [(cx + r * (0.72 + 0.4 * _R.random()) * math.cos(k * 6.283 / n), cy + r * (0.6 + 0.4 * _R.random()) * math.sin(k * 6.283 / n)) for k in range(n)]
    LICHEN.append((smooth_closed(pts), i % 3, cx, cy, r))
for (cx, cy, r) in ((790, 900, 150), (860, 790, 110), (700, 1010, 100)):
    n = 11; pts = [(cx + r * (0.8 + 0.3 * _R.random()) * math.cos(k * 6.283 / n), cy + r * (0.7 + 0.3 * _R.random()) * math.sin(k * 6.283 / n)) for k in range(n)]
    LICHEN.append((smooth_closed(pts), 1, cx, cy, r))
SPECK = [(_R.uniform(TX0 - 10, TX1 + 10), _R.uniform(0, 1900), _R.uniform(1.5, 4.5), _R.random()) for _ in range(520)]
SOOTF = [(_R.uniform(-100, 1180), _R.uniform(0, 1), _R.uniform(2, 5), _R.uniform(0.5, 1.0), _R.uniform(0, 6.28)) for _ in range(70)]
MIST = [(_R.uniform(-200, 1200), _R.uniform(500, 1500), _R.uniform(260, 520), _R.uniform(50, 110), _R.uniform(0.3, 1.0), _R.uniform(0, 6.28)) for _ in range(9)]
LEAVES = [(_R.uniform(-100, 1180), _R.uniform(0, 1), _R.uniform(0.6, 1.2), _R.uniform(0, 6.28), i % 3) for i in range(11)]
CANOPY = []
for i in range(26):
    cx = _R.uniform(-80, 1160); cy = _R.uniform(-60, 300); r = _R.uniform(90, 210)
    n = 10; CANOPY.append(([(r * (0.75 + 0.35 * _R.random()) * math.cos(k * 6.283 / n), r * (0.6 + 0.3 * _R.random()) * math.sin(k * 6.283 / n)) for k in range(n)], cx, cy, _R.uniform(0, 6.28), i % 3))

PALE_BARK, PALE_SH, PALE_HI = (204, 200, 180), (140, 136, 126), (240, 238, 214)
SOOT_BARK, SOOT_SH, SOOT_HI = (78, 68, 74), (46, 40, 50), (150, 128, 122)


def sky(c, t, soot):
    top = mix((150, 204, 206), (96, 92, 110), soot); mid = mix((206, 232, 212), (150, 128, 128), soot); low = mix((236, 240, 206), (198, 150, 118), soot)
    sh = skia.GradientShader.MakeLinear([skia.Point(0, -200), skia.Point(0, 2000)], [C(top), C(mid), C(low)], [0, 0.5, 1])
    c.drawRect(skia.Rect(-400, -400, 1480, 2400), skia.Paint(Shader=sh))
    glow(c, 150, 420, 620, mix((255, 250, 214), (255, 190, 130), soot), 120 - 50 * soot)


def chimneys(c, t, soot, a=1.0):
    """the mills on the horizon, seen through a gap in the wood: sheds, tall chimneys, smoke leaning right in the wind"""
    if a <= 0.01: return
    base = 1260
    col = mix((128, 160, 158), (66, 56, 72), soot)
    for x, w, h in ((-40, 220, 150), (150, 160, 110), (290, 190, 170)):
        p = skia.Path(); p.moveTo(x, base); p.lineTo(x, base - h)
        for k in range(4): p.lineTo(x + w * (k + 0.5) / 4, base - h - 36); p.lineTo(x + w * (k + 1) / 4, base - h)   # saw tooth roof
        p.lineTo(x + w, base); p.close(); c.drawPath(p, P(col, 255 * a))
        for k in range(3):
            c.drawRect(skia.Rect(x + 24 + k * w / 3.4, base - h + 44, x + 44 + k * w / 3.4, base - h + 84), P(mix(col, (255, 190, 110), 0.5 * soot + 0.15), 200 * a))
    for i, (x, h, w) in enumerate(((60, 470, 30), (210, 560, 34), (352, 420, 28))):
        p = poly([(x - w / 2, base), (x - w * 0.36, base - h), (x + w * 0.36, base - h), (x + w / 2, base)])
        c.drawPath(p, P(col, 255 * a)); c.drawPath(diffp(p, (-6, 0)), P(mix(col, (20, 16, 30), 0.3), 255 * a))
        c.drawRect(skia.Rect(x - w * 0.46, base - h - 8, x + w * 0.46, base - h + 10), P(mix(col, (20, 16, 30), 0.25), 255 * a))
        s2 = smooth(soot * 1.4)
        if s2 > 0.02:
            for k in range(9):                                  # one plume = overlapping puffs that drift, grow and thin out
                ph = (t * 0.22 + k / 9.0 + i * 0.31) % 1.0
                px = x + 30 + 420 * ph ** 1.15 + 14 * math.sin(t * 0.7 + k); py = base - h - 30 - 250 * ph ** 0.8 + 10 * math.sin(t * 0.5 + k * 2)
                r = 30 + 150 * ph
                c.drawCircle(px, py, r, P(mix((58, 50, 60), (130, 112, 112), ph), 235 * s2 * a * (1 - ph) ** 0.7, MaskFilter=blur(5 + 12 * ph)))


def far_trees(c, t, soot):
    for layer, (y0, colA, colB, n, wmin, wmax) in enumerate(((1330, (150, 196, 176), (124, 112, 120), 7, 60, 110), (1420, (104, 158, 138), (92, 82, 94), 5, 90, 150))):
        col = mix(colA, colB, soot); rs = np.random.default_rng(40 + layer)
        for i in range(n):
            x = rs.uniform(-60, 1140); w = rs.uniform(wmin, wmax)
            if 380 < x < 980 and layer == 1: continue
            p = poly([(x - w / 2, 2100), (x - w * 0.32, 500), (x - w * 0.36, -100), (x + w * 0.36, -100), (x + w * 0.3, 500), (x + w / 2, 2100)])
            c.drawPath(p, P(col)); c.drawPath(diffp(p, (-w * 0.2, 0)), P(mix(col, (40, 40, 60), 0.16)))
        c.drawRect(skia.Rect(-400, y0 + 80, 1480, 2400), P(mix(col, (40, 50, 60), 0.12)))
    for (x, y, w, h, a, ph) in MIST:                            # mist drifting between the trunks
        c.drawOval(skia.Rect(x + 50 * math.sin(t * 0.13 + ph) - w, y - h, x + 50 * math.sin(t * 0.13 + ph) + w, y + h), P(mix((240, 248, 232), (170, 150, 150), soot), 46 * a, MaskFilter=blur(40)))


def canopy(c, t, soot):
    for pts, cx, cy, ph, k in CANOPY:
        sx = 8 * math.sin(t * 0.9 + ph); sy = 4 * math.sin(t * 0.7 + ph * 2)
        col = mix([(72, 128, 86), (92, 150, 96), (56, 108, 84)][k], [(52, 58, 62), (66, 70, 70), (42, 46, 54)][k], soot)
        p = smooth_closed([(cx + x + sx, cy + y + sy) for x, y in pts])
        c.drawPath(p, P(col)); c.drawPath(diffp(p, (-10, -10)), P(mix(col, (20, 30, 50), 0.28)))
        c.drawPath(diffp(p, (6, 7)), P(mix(col, (240, 250, 200), 0.3 - 0.2 * soot), 200))


def trunk(c, t, soot):
    """the hero trunk: pale lichen covered bark that soot slowly blackens (the lichen dies back as it does)"""
    base = mix(PALE_BARK, SOOT_BARK, soot); sh = mix(PALE_SH, SOOT_SH, soot); hi = mix(PALE_HI, SOOT_HI, soot)
    c.drawPath(TRUNK, P((20, 30, 40), 70, MaskFilter=blur(30)))
    c.drawPath(TRUNK, P(base))
    c.save(); c.clipPath(TRUNK, skia.ClipOp.kIntersect, True)
    c.drawRect(skia.Rect(TX1 - 150, -100, TX1 + 200, 2100), P(sh, 150, MaskFilter=blur(50)))          # the trunk turns away from the light on the right
    c.drawRect(skia.Rect(TX0 - 100, -100, TX0 + 46, 2100), P(hi, 120, MaskFilter=blur(26)))
    for x, y, w, h, a in PLATES:                               # bark plates
        c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(x - w / 2, y - h / 2, x + w / 2, y + h / 2), 18, 18), P(mix(base, hi, 0.5), 60 * a))
    for x, y, ln, w, dx, cv in FURROWS:                        # furrows: dark cracks with a lit lip on their right
        p = skia.Path(); p.moveTo(x, y); p.cubicTo(x + cv, y + ln * 0.3, x + dx - cv, y + ln * 0.7, x + dx, y + ln)
        c.drawPath(p, SP(sh, w, 235)); q = skia.Path(p); q.offset(w * 0.55, 0); c.drawPath(q, SP(hi, 2.6, 130))
    la = 1 - smooth(soot * 1.35)
    if la > 0.01:
        for p, k, cx, cy, r in LICHEN:
            col = [(206, 220, 190), (232, 230, 212), (176, 200, 170)][k]
            c.drawPath(p, P(col, 235 * la)); c.drawPath(diffp(p, (-5, -5)), P(mix(col, (110, 130, 120), 0.4), 160 * la))
            c.drawPath(diffp(p, (4, 4)), P((250, 252, 236), 170 * la))
            for j in range(5): c.drawCircle(cx + r * 0.5 * math.cos(j * 2.4 + k), cy + r * 0.4 * math.sin(j * 1.7 + k), 4, P((120, 140, 126), 140 * la))
    for x, y, r, a in SPECK:                                   # grain: pale flecks on clean bark, soot grains on dirty bark
        c.drawCircle(x, y, r, P(mix((120, 120, 110), (14, 12, 18), soot) if a > 0.45 else mix((244, 244, 226), (96, 88, 96), soot), 60 + 110 * a))
    if soot > 0.02:
        c.drawRect(skia.Rect(0, -100, 1080, 2100), P((20, 16, 24), 24 * soot))
    c.restore()
    c.drawPath(diffp(TRUNK, (7, 0)), P(hi, 200))


def branch(c, t, soot):
    base = mix((150, 140, 120), (52, 46, 54), soot); sh = mix((104, 96, 92), (30, 26, 36), soot); hi = mix((214, 208, 180), (100, 92, 100), soot)
    sw = 2.5 * math.sin(t * 1.1)
    pts = [(TX0 + 40, 800), (360, 786 + sw * 0.3), (PERCH[0], PERCH[1] + 22 + sw * 0.6), (110, 716 + sw), (-60, 640 + sw * 1.4)]
    p = skia.Path(); p.moveTo(*pts[0]); p.cubicTo(*pts[1], *pts[2], *pts[3]); p.lineTo(*pts[4])
    c.drawPath(p, SP((20, 30, 40), 62, 60, MaskFilter=blur(12)))
    for w, col, off in ((56, sh, 0), (50, base, -4), (10, hi, -22)):
        q = skia.Path(p); q.offset(0, off); c.drawPath(q, SP(col, w))
    tw = skia.Path(); tw.moveTo(150, 712 + sw); tw.quadTo(120, 620 + sw, 60, 560 + sw * 1.5); c.drawPath(tw, SP(base, 16)); c.drawPath(tw, SP(hi, 3, 150))
    for (lx, ly, rot) in ((70, 556, -40), (96, 610, 30), (36, 600, -100)):                              # oak leaves on the twig
        c.save(); c.translate(lx, ly + sw * 1.5); c.rotate(rot + 6 * math.sin(t * 1.6 + lx))
        lf = smooth_closed([(0, 0), (14, -12), (30, -8), (44, -18), (58, -8), (74, -10), (84, 0), (74, 10), (58, 8), (44, 18), (30, 8), (14, 12)])
        col = mix((98, 158, 92), (62, 70, 66), soot)
        c.drawPath(lf, P(col)); c.drawPath(diffp(lf, (0, -5)), P(mix(col, (20, 40, 50), 0.3))); c.drawLine(4, 0, 78, 0, SP(mix(col, (240, 250, 200), 0.4), 2))
        c.restore()
    return sw


def falling(c, t, soot):
    for x, ph, s, rot, k in LEAVES:
        u = (t * 0.07 * s + ph) % 1.0
        px = x + 60 * math.sin(u * 9 + rot); py = -60 + 2100 * u
        c.save(); c.translate(px, py); c.rotate(math.degrees(rot) + 200 * u); c.scale(s, s * (0.5 + 0.5 * abs(math.sin(u * 14 + rot))))
        lf = smooth_closed([(0, 0), (10, -8), (24, -4), (34, 0), (24, 4), (10, 8)])
        c.drawPath(lf, P(mix([(120, 170, 100), (190, 170, 90), (150, 190, 120)][k], (70, 70, 70), soot), 210)); c.restore()
    if soot > 0.05:
        for x, ph, r, a, w in SOOTF:                           # soot drifting down
            u = (t * 0.05 + ph) % 1.0
            c.drawCircle(x + 30 * math.sin(u * 7 + w), 2000 * u - 40, r, P((24, 20, 26), 170 * a * soot))


# ----------------------------------------------------------------------------------------------- the moths
_MS = np.random.default_rng(5)
PEPPER = [(_MS.uniform(-1, 1), _MS.uniform(-1, 1), _MS.uniform(1.2, 3.4)) for _ in range(150)]


def _wing(side):
    """a resting peppered moth holds its wings flat and spread: a long fore wing, a rounder hind wing tucked under it"""
    s = side
    fore = smooth_closed([(s * 6, -30), (s * 40, -52), (s * 86, -58), (s * 116, -44), (s * 122, -18), (s * 96, 14), (s * 54, 30), (s * 10, 22)])
    hind = smooth_closed([(s * 8, 8), (s * 50, 16), (s * 88, 28), (s * 92, 56), (s * 66, 76), (s * 32, 70), (s * 8, 46)])
    return fore, hind


def moth(c, x, y, s=1.0, rot=0.0, dark=0.0, a=1.0, t=0.0, flut=0.0, ring=None, fold=0.0):
    """dark 0 = the pale speckled form, 1 = the black form. flut: a small shiver of the wings."""
    if a <= 0.01: return
    wc = mix((238, 234, 220), (40, 36, 44), dark); wsh = mix((196, 192, 184), (22, 20, 28), dark); whi = mix((255, 255, 246), (150, 134, 140), dark)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    if a < 1: c.saveLayerAlpha(None, int(255 * a))
    if fold < 0.5: c.drawOval(skia.Rect(-112, -40, 122, 86), P((20, 20, 30), 70 * (1 - 2 * fold), MaskFilter=blur(9)))                # the moth's shadow on the bark
    for side in (-1, 1):
        c.save(); c.scale(max(0.12, (1 - 0.05 * flut * (0.5 + 0.5 * math.sin(t * 62.8 + 0.3))) * (1 - 0.62 * fold)), 1)
        fore, hind = _wing(side)
        for path, k in ((hind, 0.9), (fore, 1.0)):
            c.drawPath(path, P(mix(wc, wsh, 1 - k)))
            c.drawPath(diffp(path, (-5, -5)), P(wsh, 200))
            c.drawPath(diffp(path, (3.5, 4)), P(whi, 220))
            c.save(); c.clipPath(path, skia.ClipOp.kIntersect, True)
            for i, (u, v, r) in enumerate(PEPPER):              # the "pepper": black flecks on white, faint grey flecks on black
                if (i % 2 == 0) == (side > 0):
                    c.drawCircle(side * (64 + 60 * u), 10 + 66 * v, r, P(mix((30, 28, 36), (84, 78, 90), dark), 230 - 110 * dark))
            for (x0, y0, x1, y1, x2, y2) in ((40, -50, 52, -12, 44, 28), (84, -56, 90, -20, 74, 22), (30, 20, 56, 44, 60, 72)):   # the wavy cross lines
                q = skia.Path(); q.moveTo(side * x0, y0); q.quadTo(side * x1, y1, side * x2, y2)
                c.drawPath(q, SP(mix((60, 56, 64), (80, 74, 88), dark), 2.6, 170 - 60 * dark))
            c.restore()
        c.restore()
    body = smooth_closed([(0, -40), (11, -30), (13, -6), (10, 30), (5, 62), (0, 70), (-5, 62), (-10, 30), (-13, -6), (-11, -30)])
    c.drawPath(body, P(mix((214, 208, 196), (30, 26, 34), dark))); c.drawPath(diffp(body, (-4, -3)), P(wsh)); c.drawPath(diffp(body, (2.5, 3)), P(whi, 200))
    for k in range(5): c.drawLine(-8, 6 + k * 11, 8, 6 + k * 11, SP(mix((120, 116, 112), (70, 64, 76), dark), 2, 150))
    c.drawCircle(0, -36, 9, P(mix((200, 194, 184), (28, 24, 32), dark)))
    for side in (-1, 1):                                        # feathery antennae
        q = skia.Path(); q.moveTo(side * 4, -42); q.quadTo(side * 16, -64, side * 34, -74 + 2 * math.sin(t * 3 + side)); c.drawPath(q, SP(mix((90, 84, 84), (60, 54, 66), dark), 2.6))
    if a < 1: c.restore()
    c.restore()
    if ring is not None and ring[0] > 0.01:
        rr = 150 * s * (1.25 - 0.25 * smooth(ring[0]))
        c.drawCircle(x, y + 10 * s, rr, SP(ring[1], 7, 255 * min(1, ring[0] * 1.5))); c.drawCircle(x, y + 10 * s, rr, SP(ring[1], 18, 60 * min(1, ring[0]), MaskFilter=blur(8)))


# ----------------------------------------------------------------------------------------------- the great tit
YEL, YEL_SH, OLV, BLU, BLK, WHT = (240, 208, 74), (196, 150, 56), (118, 136, 78), (104, 134, 170), (26, 26, 36), (246, 246, 238)


def _tit_head(c, look=0.0, blink=1.0, gulp=0.0, beak=0.0, prey=None):
    """head centre at the origin, facing +x. look tilts the head, beak 0..1 opens it"""
    c.save(); c.rotate(look)
    head = skia.Path(); head.addCircle(0, 0, 37)
    c.drawPath(head, P(BLK))
    cheek = smooth_closed([(-16, 4), (2, -4), (20, 0), (26, 12), (12, 24), (-8, 22)])
    c.drawPath(cheek, P(WHT)); c.drawPath(diffp(cheek, (0, -5)), P((204, 210, 214)))
    c.drawPath(diffp(head, (4, 5)), P((90, 96, 130), 200))                                            # rim on the cap
    for sgn, op_ in ((-1, -beak * 15), (1, beak * 15)):
        c.save(); c.translate(30, 2); c.rotate(op_)
        bk = poly([(0, -7 if sgn < 0 else 0), (30, 0), (0, 0 if sgn < 0 else 7)]); c.drawPath(bk, P((44, 44, 54) if sgn < 0 else (70, 70, 84))); c.restore()
    if prey is not None: prey(c, 52, 4)
    c.drawCircle(14, -13, 7.0, P((70, 74, 96))); c.drawCircle(14, -13, 5.6, P((8, 8, 14)))
    if blink < 0.5: c.drawCircle(14, -13, 8, P(BLK)); c.drawLine(7, -13, 21, -13, SP((90, 90, 110), 2))
    else: c.drawCircle(16, -15.5, 2.3, P((255, 255, 255)))
    c.restore()


def tit_perched(c, x, y, t, look=0.0, crouch=0.0, blink=1.0, beak=0.0, prey=None, s=1.0, bob=0.0, tailup=0.0, face=1.0, wingopen=0.0):
    """perched side on, facing right; (x, y) = the feet on the branch"""
    c.save(); c.translate(x, y + bob); c.scale(s * face, s)
    br = 1.6 * math.sin(t * 5.2)
    c.translate(0, crouch * 16); c.rotate(-8 + crouch * 16)
    for fx in (-6, 12):                                         # legs and gripping toes
        c.drawLine(fx, -30, fx + 2, -2 - crouch * 8, SP((70, 80, 100), 5.5))
        for dx in (-13, 0, 13): c.drawLine(fx + 2, -2 - crouch * 8, fx + 2 + dx, 9 - crouch * 8, SP((70, 80, 100), 4.5))
    c.save(); c.translate(-52, -62); c.rotate(22 - 26 * tailup + 3 * math.sin(t * 2.3))                # tail
    tl = poly([(0, -9), (-86, -15), (-92, 4), (-84, 13), (0, 10)]); c.drawPath(tl, P(BLU)); c.drawPath(diffp(tl, (0, -6)), P((70, 92, 128))); c.drawLine(-88, -13, -4, -8, SP(WHT, 3))
    c.restore()
    body = smooth_closed([(-62, -74), (-34, -104 - br), (10, -110 - br), (44, -92), (56, -64), (40, -34), (4, -22), (-36, -30), (-58, -50)])
    c.drawPath(body, P(YEL)); c.drawPath(diffp(body, (0, -12)), P(YEL_SH, 220)); c.drawPath(diffp(body, (-4, 5)), P((255, 240, 150), 220))
    c.save(); c.clipPath(body, skia.ClipOp.kIntersect, True)
    c.drawPath(smooth_closed([(34, -96), (52, -70), (36, -40), (8, -22), (-4, -24), (22, -52), (26, -80)]), P(BLK))    # the black stripe down the belly
    c.restore()
    wing = smooth_closed([(-70, -70), (-40, -100 - br), (0, -104 - br), (18, -86), (2, -62), (-34, -50), (-66, -54)])
    c.drawPath(wing, P(BLU)); c.drawPath(diffp(wing, (0, -8)), P((70, 92, 128))); c.drawPath(diffp(wing, (-3, 5)), P((170, 196, 224), 220))
    c.drawPath(smooth_closed([(-40, -100 - br), (-4, -106 - br), (8, -96), (-20, -88)]), P(OLV))        # olive mantle
    c.drawLine(-52, -78, -6, -72, SP(WHT, 5))                                                          # the white wing bar
    if wingopen > 0.04:                                         # just landed: the wings are still half open, then fold
        c.save(); c.translate(-14, -92); c.rotate(-18); c.scale(0.86, 0.86); _wingshape(c, wingopen); c.restore()
    c.translate(46, -116 - br * 0.6); _tit_head(c, look, blink, 0, beak, prey)
    c.restore()


def _wingshape(c, flap, far=False):
    """one wing seen from the side, hinged at the shoulder (origin). flap 1 = raised over the back, -1 = swept below the belly;
    mid stroke it is edge on, so it foreshortens, the way a real wing does"""
    k = flap if abs(flap) > 0.12 else (0.12 if flap >= 0 else -0.12)
    c.save(); c.skew(-0.28 * k, 0); c.scale(1, k)
    w = smooth_closed([(-22, 0), (-16, -54), (-2, -100), (14, -122), (30, -112), (36, -84), (30, -70), (38, -52), (30, -40), (34, -20), (24, 0)])
    base = (78, 104, 140) if far else BLU
    c.drawPath(w, P(base)); c.drawPath(diffp(w, (-6, 0)), P((62, 84, 120)))
    if not far:
        c.drawPath(diffp(w, (4, 0)), P((170, 196, 224), 210))
        c.drawLine(-14, -46, 30, -52, SP(WHT, 5))                                                      # wing bar
        for x in (-6, 6, 18): c.drawLine(x, -62, x + 6, -108 + abs(x) * 0.8, SP((62, 84, 120), 2.2, 170))   # flight feathers
    c.restore()


def tit_flying(c, x, y, ang, flap, s=1.0, prey=None, beak=0.0, legs=0.0):
    """in flight, side on, the body along its path (ang in degrees, kept shallow by the caller), wings beating: flap -1 (down) .. 1 (up)"""
    c.save(); c.translate(x, y); c.rotate(ang); c.scale(s, s)
    tl = poly([(-44, -7), (-126, -16 - 5 * flap), (-134, 0), (-126, 16 + 5 * flap), (-44, 7)]); c.drawPath(tl, P(BLU)); c.drawPath(diffp(tl, (0, -6)), P((70, 92, 128))); c.drawLine(-124, -13, -46, -5, SP(WHT, 3))
    c.save(); c.translate(-2, -14); _wingshape(c, flap * 0.9 + 0.05, far=True); c.restore()
    body = smooth_closed([(-56, -4), (-30, -26), (14, -28), (44, -14), (50, 6), (30, 22), (-10, 24), (-44, 14)])
    c.drawPath(body, P(YEL)); c.drawPath(diffp(body, (0, -9)), P(YEL_SH, 220)); c.drawPath(diffp(body, (-3, 4)), P((255, 240, 150), 200))
    c.save(); c.clipPath(body, skia.ClipOp.kIntersect, True); c.drawRect(skia.Rect(-60, -40, 30, -10), P(OLV)); c.drawRect(skia.Rect(6, 8, 60, 30), P(BLK)); c.restore()
    for fx in (-14, 0):                                         # legs tucked back in flight, swung down and forward to land or push off
        c.drawLine(fx, 18, fx - 14 + 22 * legs, 27 + 26 * legs, SP((70, 80, 100), 4.5 + legs))
        if legs > 0.5:
            for dx in (-10, 0, 10): c.drawLine(fx - 14 + 22 * legs, 27 + 26 * legs, fx - 14 + 22 * legs + dx, 36 + 26 * legs, SP((70, 80, 100), 4))
    c.save(); c.translate(-8, -10); _wingshape(c, flap); c.restore()
    c.translate(60, -12); _tit_head(c, 0, 1.0, 0, beak, prey)
    c.restore()


def tit_front(c, x, y, s=1.0, lift=0.0, wings=0.0, legs=True):
    """the bird seen from the front, for the moment it turns round in a hop: round yellow belly with the black stripe, black cap, white cheeks,
    wings half open for balance. (x, y) = its feet."""
    c.save(); c.translate(x, y); c.scale(s, s)
    for fx in (-14, 14):
        if not legs: c.drawLine(fx, -30, fx * 0.7, -16, SP((70, 80, 100), 5)); continue
        c.drawLine(fx, -30, fx, -2 + lift * 0.0, SP((70, 80, 100), 5.5))
        for dx in (-9, 0, 9): c.drawLine(fx, -2, fx + dx, 8, SP((70, 80, 100), 4.5))
    for sgn in (-1, 1):                                         # wings lifted a little away from the body
        w = smooth_closed([(sgn * 30, -104), (sgn * (56 + 34 * wings), -112 - 18 * wings), (sgn * (66 + 46 * wings), -74), (sgn * (52 + 30 * wings), -40), (sgn * 30, -44)])
        c.drawPath(w, P(BLU)); c.drawPath(diffp(w, (0, -7)), P((70, 92, 128))); c.drawLine(sgn * 36, -80, sgn * (58 + 34 * wings), -78, SP(WHT, 4.5))
    body = smooth_closed([(0, -122), (34, -112), (48, -80), (42, -46), (20, -26), (0, -22), (-20, -26), (-42, -46), (-48, -80), (-34, -112)])
    c.drawPath(body, P(YEL)); c.drawPath(diffp(body, (-9, -4)), P(YEL_SH, 220)); c.drawPath(diffp(body, (4, 4)), P((255, 240, 150), 220))
    c.save(); c.clipPath(body, skia.ClipOp.kIntersect, True); c.drawPath(smooth_closed([(-11, -124), (11, -124), (9, -70), (5, -24), (-5, -24), (-9, -70)]), P(BLK)); c.restore()
    c.translate(0, -138)
    head = skia.Path(); head.addCircle(0, 0, 37); c.drawPath(head, P(BLK)); c.drawPath(diffp(head, (4, 5)), P((90, 96, 130), 200))
    for sgn in (-1, 1):
        ck = smooth_closed([(sgn * 8, 2), (sgn * 26, -4), (sgn * 34, 10), (sgn * 24, 24), (sgn * 8, 22)]); c.drawPath(ck, P(WHT)); c.drawPath(diffp(ck, (0, -5)), P((204, 210, 214)))
        c.drawCircle(sgn * 15, -12, 6.2, P((70, 74, 96))); c.drawCircle(sgn * 15, -12, 4.9, P((8, 8, 14))); c.drawCircle(sgn * 15 + 1.6, -14, 1.9, P((255, 255, 255)))
    c.drawPath(poly([(-9, 0), (9, 0), (0, 20)]), P((150, 154, 176))); c.drawPath(poly([(-9, 0), (0, 0), (0, 20)]), P((96, 100, 124)))
    c.restore()
