"""placeholder word timings from a script (replaced by the real take's alignment)"""
import json, sys, re
def make(txt, cps=15.5):
    t = 0.0; out = []
    for w in txt.split():
        core = re.sub(r'[^A-Za-z0-9\']', '', w)
        d = max(0.12, len(core) / cps + 0.06)
        out.append(dict(w=w.replace('...', ''), t0=round(t, 3), t1=round(t + d, 3)))
        t += d
        if w.endswith('...'): t += 0.55
        elif w[-1] in '.?!': t += 0.38
        elif w[-1] in ',': t += 0.16
        else: t += 0.03
    return out
if __name__ == '__main__':
    w = make(open(sys.argv[1]).read()); json.dump(w, open(sys.argv[2], 'w')); print(len(w), 'words', w[-1]['t1'])
