"""motion strip: scene frames (no titles) between t0 and t1 every `step` frames, cropped, tiled"""
import sys
folder, t0, t1, step, x0, y0, x1, y1, cols, out = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), int(sys.argv[4]), *map(int, sys.argv[5:9]), int(sys.argv[9]), sys.argv[10]
sys.path[:0] = ['/home/claude/short', folder, '/home/claude/w1124/lib']
import build as B, skia
from PIL import Image
ims = []; f = int(round(t0 * 30))
while f <= t1 * 30:
    s = skia.Surface(1080, 1920); B.scene(s.getCanvas(), f / 30)
    im = Image.fromarray(s.makeImageSnapshot().toarray()[:, :, [2, 1, 0]]).crop((x0, y0, x1, y1)); k = 240 / im.width
    ims.append(im.resize((240, int(im.height * k)))); f += step
h = ims[0].height; rows = (len(ims) + cols - 1) // cols
sh = Image.new('RGB', (240 * cols, h * rows))
for i, im in enumerate(ims): sh.paste(im, (240 * (i % cols), h * (i // cols)))
sh.save(out, quality=88); print(len(ims))
