"""Restrained mix (pattern: w1109 lightning mix.py). Voice leads; composed score about 20 dB under with a 4 dB duck; ambience about 26 dB under;
3 to 5 effects about 10 dB under; no whooshes; two pass loudnorm to -14 LUFS, true peak -1.5 dBTP."""
import json, subprocess
import numpy as np, soundfile as sf, librosa
SR = 44100; SFX = '/home/claude/lp/assets'


def load(path):
    x, _ = librosa.load(path, sr=SR, mono=True); return x / (np.abs(x).max() or 1)


def tick(f=2600, dur=0.05):
    n = int(dur * SR); tt = np.arange(n) / SR
    return np.sin(2 * np.pi * f * tt) * np.exp(-tt * 90) + 0.5 * np.random.default_rng(3).normal(0, 1, n) * np.exp(-tt * 160)


def mix(OUT, MUS, DUR, effects, ambience, sections, shape_pts):
    """effects: (name or array, t0, gain, maxlen, fade_out, start_offset); ambience: (name, [(t, gain)...]) or None"""
    N = int(DUR * SR); t = np.arange(N) / SR; fx = np.zeros(N); amb = np.zeros(N)
    for name, t0, g, maxlen, fo, off in effects:
        x = load(f'{SFX}/{name}.wav') if isinstance(name, str) else name / (np.abs(name).max() or 1)
        x = x[int(off * SR):]
        if maxlen: x = x[:int(maxlen * SR)]
        i = int(t0 * SR); n = min(len(x), N - i); env = np.ones(n); b = max(1, min(n, int(fo * SR))); env[-b:] *= np.linspace(1, 0, b)
        a = min(n, int(0.01 * SR)); env[:a] *= np.linspace(0, 1, a); fx[i:i + n] += g * x[:n] * env
    if ambience:
        r_ = load(f'{SFX}/{ambience[0]}.wav'); bed = np.tile(r_, int(np.ceil(N / len(r_))))[:N]
        amb = bed * np.interp(t, [p[0] for p in ambience[1]], [p[1] for p in ambience[1]])
    mus, _ = librosa.load(MUS, sr=SR, mono=True); mus = np.pad(mus, (0, max(0, N - len(mus))))[:N]
    v, _ = librosa.load(f'{OUT}/voice.wav', sr=SR, mono=True); v = np.pad(v, (0, max(0, N - len(v))))[:N]
    env = np.abs(v); k = int(0.3 * SR); env = np.convolve(env, np.ones(k) / k, 'same'); env /= env.max() or 1
    speech = np.clip(env * 4, 0, 1); k2 = int(0.4 * SR); speech = np.convolve(speech, np.ones(k2) / k2, 'same')
    shape = np.interp(t, [p[0] for p in shape_pts], [p[1] for p in shape_pts])
    duck = 10 ** (-4 / 20) + (1 - 10 ** (-4 / 20)) * (1 - speech)
    db = lambda x: 20 * np.log10(np.sqrt(np.mean(np.asarray(x) ** 2)) + 1e-9)
    sp = env > 0.15; vref = db(v[sp])

    def to(x, under, mask=None):
        m = mask if mask is not None else (np.abs(x) > 1e-4)
        return x * 10 ** ((vref - under - db(x[m])) / 20) if m.any() else x
    lev = np.ones(N)
    for a, b in sections:
        m = (t >= a) & (t < b); lev[m] = 10 ** ((-18 - db(mus[m])) / 20)
    kk = int(0.6 * SR); lev = np.convolve(np.pad(lev, kk, mode='edge'), np.ones(kk) / kk, 'same')[kk:-kk]
    mus = to(mus * lev * shape * duck, 20, sp); fx = to(fx, 10)
    if ambience: amb = to(amb, 26, sp)
    fade = np.clip(t / 0.05, 0, 1) * np.clip((DUR - t) / 0.9, 0, 1)
    for name, mg in (('mix_music', 1.0), ('mix_nomusic', 0.0)):
        out = (v + fx + amb + mg * mus) * fade
        st = np.stack([out, out], 1).astype(np.float32)
        tmp = f'{OUT}/{name}_raw.wav'; sf.write(tmp, st / (np.abs(st).max() or 1) * 0.9, SR)
        r = subprocess.run(['ffmpeg', '-hide_banner', '-i', tmp, '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json', '-f', 'null', '-'], capture_output=True, text=True)
        js = json.loads(r.stderr[r.stderr.rindex('{'):])
        af = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={js['input_i']}:measured_TP={js['input_tp']}:measured_LRA={js['input_lra']}:"
              f"measured_thresh={js['input_thresh']}:offset={js['target_offset']}:linear=true")
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-af', af, '-ar', '44100', f'{OUT}/{name}.wav'], check=True)
    sp2 = env > 0.2
    print('music vs voice in speech', round(db(mus[sp2]) - vref, 1), '| fx', round(db(fx[np.abs(fx) > 1e-4]) - vref, 1), '| amb', round(db(amb[sp2]) - vref, 1) if ambience else None)


def encode(OUT):
    for mixn, outn in (('mix_music', 'final'), ('mix_nomusic', 'final_nomusic')):
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', f'{OUT}/silent.mp4', '-i', f'{OUT}/{mixn}.wav', '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-preset', 'slow',
                        '-b:v', '10M', '-maxrate', '12M', '-bufsize', '20M', '-pix_fmt', 'yuv420p', '-r', '30', '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-shortest', '-movflags', '+faststart', f'{OUT}/{outn}.mp4'], check=True)
