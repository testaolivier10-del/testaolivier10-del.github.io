"""Shorts thumbnail (pattern: w1109 lightning thumb.py): the strongest frame of the scene, 2 to 5 big words naming the topic, course pill."""
import sys, importlib
import numpy as np, skia
ANTON = skia.Typeface.MakeFromFile('/tmp/m/pipeline/thumbpro/fonts/Anton-Regular.ttf')
MONT = skia.Typeface.MakeFromFile('/tmp/m/pipeline/thumbpro/fonts/Montserrat.ttf')
W, H = 1080, 1920


def make(folder, t, words2, pill, pillcol, out, dy=0):
    sys.path[:0] = ['/home/claude/short', folder, '/home/claude/w1124/lib']
    import build as B, kit
    from lpk import P, C, blur
    s = skia.Surface(W, H); c = s.getCanvas(); c.translate(0, dy); B.scene(c, t)
    img = kit.finish(s.makeImageSnapshot().toarray(), t, lift=1.06)
    s = skia.Surface(W, H); c = s.getCanvas(); c.drawImage(skia.Image.fromarray(img, colorType=skia.kBGRA_8888_ColorType), 0, 0)
    sh = skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, 760)], [C((6, 8, 34), 235), C((6, 8, 34), 0)])
    c.drawRect(skia.Rect(0, 0, W, 760), skia.Paint(Shader=sh))
    size = 150; f1 = skia.Font(ANTON, size); w1 = f1.measureText(words2[0])
    if w1 > 980: size = size * 980 / w1; f1 = skia.Font(ANTON, size); w1 = f1.measureText(words2[0])
    for col, st in (((8, 10, 36), 26), ((255, 255, 255), 0)):
        pa = skia.Paint(AntiAlias=True, Color=C(col))
        if st: pa.setStyle(skia.Paint.kStroke_Style); pa.setStrokeWidth(st); pa.setStrokeJoin(skia.Paint.kRound_Join)
        c.drawString(words2[0], 540 - w1 / 2, 390, f1, pa)
    size2 = 168; f2 = skia.Font(ANTON, size2); w2 = f2.measureText(words2[1])
    if w2 > 880: size2 = size2 * 880 / w2; f2 = skia.Font(ANTON, size2); w2 = f2.measureText(words2[1])
    k = size2 / 168
    c.save(); c.translate(540, 580); c.rotate(-3.5)
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(-w2 / 2 - 40, -98 * k, w2 / 2 + 40, 96 * k), 22, 22), P((0, 0, 0), 120, MaskFilter=blur(14)))
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(-w2 / 2 - 40, -106 * k, w2 / 2 + 40, 86 * k), 22, 22), P((255, 214, 64)))
    c.drawString(words2[1], -w2 / 2, 62 * k, f2, P((16, 12, 40))); c.restore()
    fp = skia.Font(MONT, 40); fp.setEmbolden(True); wp = fp.measureText(pill)
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(540 - wp / 2 - 34, 96, 540 + wp / 2 + 34, 172), 38, 38), P(pillcol))
    c.drawString(pill, 540 - wp / 2, 149, fp, P((255, 255, 255)))
    fm = skia.Font(MONT, 38); fm.setEmbolden(True); c.drawString('LevlPrep', 1080 - fm.measureText('LevlPrep') - 48, 1560, fm, P((64, 226, 206)))
    s.makeImageSnapshot().save(out)


if __name__ == '__main__':
    a = sys.argv; make(a[1], float(a[2]), (a[3], a[4]), a[5], tuple(int(x) for x in a[6].split(",")), a[7], float(a[8]) if len(a) > 8 else 0)
