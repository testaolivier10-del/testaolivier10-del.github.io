"""Gate 2 and 3 check for the back view figure: she is drawn alone on a clear canvas at sampled frames; her filled shape must be ONE connected
region, and the elbow angle from the arm solve must stay inside 0 to 145 degrees of bend."""
import sys, math
import numpy as np, skia, cv2
folder = sys.argv[1]; sys.path[:0] = ['/home/claude/short', folder, '/home/claude/w1124/lib']
import char as CH
import build as B
calls = []
orig = CH.back
def spy(c, t, **kw): calls.append((t, kw))
CH.back = spy
N = int(B.DUR * 30); bad = 0; worst = 0.0; n = 0
for fi in range(0, N, 3):
    t = fi / 30; calls.clear()
    s = skia.Surface(1080, 1920); B.scene(s.getCanvas(), t)
    for (tt, kw) in calls:
        s2 = skia.Surface(1080, 2400); c = s2.getCanvas(); c.clear(skia.Color(0, 0, 0, 0)); orig(c, tt, **kw)
        a = s2.makeImageSnapshot().toarray()[:, :, 3] > 40
        k, lab, stats, _ = cv2.connectedComponentsWithStats(a.astype(np.uint8), 8)
        big = [i for i in range(1, k) if stats[i, cv2.CC_STAT_AREA] > 60]
        n += 1
        if len(big) != 1: bad += 1; print('NOT ONE BODY at', round(t, 2), len(big))
        for side, key in ((-1, 'hl'), (1, 'hr')):
            hp = kw.get(key)
            if hp is None: continue
            sh = (CH.X0 + kw.get('sway', 0) + side * 106, CH.SHY + kw.get('dy', 0) + 14)
            d = min(math.hypot(hp[0] - sh[0], hp[1] - sh[1]), CH.U_ARM + CH.F_ARM - 1)
            inner = math.degrees(math.acos(max(-1, min(1, (CH.U_ARM ** 2 + CH.F_ARM ** 2 - d * d) / (2 * CH.U_ARM * CH.F_ARM)))))
            worst = max(worst, 180 - inner)
print(folder.split('/')[-1], 'frames with her:', n, '| not one connected body:', bad, '| largest elbow bend (deg):', round(worst, 1))
