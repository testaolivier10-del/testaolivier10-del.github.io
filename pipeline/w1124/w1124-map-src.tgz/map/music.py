import requests, sys
K=open('/root/.lpkey/k').read().strip()
plan = {
 "positive_global_styles": ["cinematic documentary score", "marimba", "pizzicato strings", "felt piano", "curious and bright", "restrained", "high quality mix"],
 "negative_global_styles": ["vocals", "lyrics", "drum kit", "EDM", "trap beat", "comedy", "lo-fi", "trailer brass", "horror stingers"],
 "sections": [
  {"section_name": "the classroom map", "positive_local_styles": ["curious light marimba and pizzicato", "a question hanging", "bright morning", "C major"], "negative_local_styles": ["drums"], "duration_ms": 6500, "lines": []},
  {"section_name": "sailors, 1569", "positive_local_styles": ["a gentle sea shanty lilt in the strings", "accordion hint", "rolling waves feel"], "negative_local_styles": ["drums"], "duration_ms": 8500, "lines": []},
  {"section_name": "the stretch", "positive_local_styles": ["rising scale, stretching upward", "building tension", "tremolo strings"], "negative_local_styles": ["drums"], "duration_ms": 5200, "lines": []},
  {"section_name": "the slide and the shrink", "positive_local_styles": ["a descending glide", "playful", "then a clear bright accent"], "negative_local_styles": ["drums"], "duration_ms": 3900, "lines": []},
  {"section_name": "fourteen times", "positive_local_styles": ["broad warm chord", "awe", "full strings"], "negative_local_styles": ["drums"], "duration_ms": 3400, "lines": []},
  {"section_name": "every map bends something", "positive_local_styles": ["calm resolution", "marimba motif returns", "final chord in C major, held"], "negative_local_styles": [], "duration_ms": 6400, "lines": []}
 ]
}
r = requests.post('https://api.elevenlabs.io/v1/music?output_format=mp3_44100_192', headers={'xi-api-key': K}, json={'composition_plan': plan, 'model_id': 'music_v1'}, timeout=600)
print(r.status_code, r.text[:300] if r.status_code != 200 else len(r.content))
if r.status_code == 200: open(sys.argv[1], 'wb').write(r.content)
