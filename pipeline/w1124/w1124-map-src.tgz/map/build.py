"""w1124-03-greenland-africa (AP Human Geography, map projections, CED 1.1). 1080x1920, 30 fps, all code.
Logline: on her classroom map Greenland looks as big as Africa; the map was built to keep compass lines straight, and it pays for that in size.
Person: a student, designed new (ginger hair in a bun, emerald sweater), approved back view and face model. She appears in the wide shots at the
wall map; the cut ins are the map itself.
Shots: wide, she points from Greenland to Africa / her face, which is bigger? / cut in: a caravel on one straight line, one compass heading
(Mercator, 1569) / circles of equal real size swell toward the pole / wide: Greenland lifts off, slides to the equator and shrinks (true size
re projection every frame) / cut in: it sits inside Africa, 14 times / wide: where the map drew it (dashed) and its real size.
Accuracy: outlines are Natural Earth; Mercator y = ln tan(45 + lat/2); a straight line on it is a rhumb line (constant bearing); linear stretch
is sec(lat) (1 at the equator, 2 at 60 N, about 3 at 70 N); the moved Greenland keeps every point's real distance and bearing from its centre;
Africa 30.4 million km2, Greenland 2.17 million km2, about 14 to 1."""
import sys, math, os
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/map', '/home/claude/w1124/lib']
import char as CH, mapart as M, hands as HN
import numpy as np, skia
import kit, lpk, art as A
from kit import Words, Short, ease_io, Wt, Y, R, TL
from lpk import P, SP, C, blur, smooth, lerp, mix, poly

CH.SW, CH.SW_SH, CH.SW_HI = (40, 150, 110), (24, 100, 92), (150, 236, 190)
CH.SKIN, CH.SKIN_SH, CH.SKIN_HI = (246, 206, 180), (212, 156, 138), (255, 234, 214)
CH.HAIR, CH.HAIR_SH, CH.HAIR_HI = (196, 92, 44), (140, 56, 36), (250, 160, 96)
CH.JEAN, CH.JEAN_SH = (70, 78, 120), (46, 52, 88)
CH.HAIRSTYLE = 'bun'
KEYL = (255, 236, 200)

WD = Words('/home/claude/w1124/map/out/words.json'); at = WD.at
T_GR, T_AF, T_SO, T_THIS, T_MERC, T_1569 = at('greenland'), at('africa'), at('so'), at('this'), at('mercator'), at('1569')
T_STR, T_ONE, T_DIR, T_TO, T_STRETCH, T_MORE2 = at('straight'), at('one', 2), at('direction'), at('to'), at('stretch'), at('more', 2)
T_SLIDE, T_GR2, T_SHRINK, T_AF2, T_14, T_EVERY, T_BEND, T_THIS2 = at('slide'), at('greenland', 2), at('shrink'), at('africa', 2), at('fourteen'), at('every'), at('bend'), at('this', 2)
T_END = WD.end() + 0.35; DUR = T_END + 1.5
CU = (T_SO - 0.1, T_THIS - 0.12)
VKEYS = None
GOLD = (255, 226, 110)
WIDE = (-54.0, 53.5, 4.8)
LIS, BAR = (-9.1, 38.7), (-61.0, 13.0)
BEARING = math.degrees(math.atan2(BAR[0] - LIS[0], M.my(BAR[1]) - M.my(LIS[1]))) % 360


PUSH_L = 150


def keys(ks, t):
    if t <= ks[0][0]: return ks[0][1:]
    for a, b in zip(ks, ks[1:]):
        if a[0] <= t < b[0]:
            u = ease_io((t - a[0]) / (b[0] - a[0])); return tuple(lerp(x, y, u) for x, y in zip(a[1:], b[1:]))
    return ks[-1][1:]


def pop(t, t0, d=0.25):
    if t < t0: return 0.0
    u = min(1.0, (t - t0) / d) - 1; return 1 + 3.2 * u ** 3 + 2.2 * u ** 2


def rail(c):
    """the bottom of the wall map: its wooden rail, and the classroom wall under it"""
    c.drawRect(skia.Rect(0, 1452, 1080, 1920), P((206, 190, 168))); c.drawRect(skia.Rect(0, 1560, 1080, 1920), P((150, 128, 120)))
    c.drawRect(skia.Rect(0, 1430, 1080, 1462), P((150, 100, 64))); c.drawRect(skia.Rect(0, 1430, 1080, 1438), P((210, 160, 110))); c.drawRect(skia.Rect(0, 1462, 1080, 1476), P((60, 40, 50), 90))


def her(c, t, **kw):
    CH.back(c, t, sway=3 * math.sin(t * 0.8), rim_boost=0.5, rimcol=KEYL, **kw)


def aim_hand(target, reach=272):
    sx, sy = CH.X0 + 106, CH.SHY + 14
    d = math.hypot(target[0] - sx, target[1] - sy) or 1
    return (sx + (target[0] - sx) / d * reach, sy + (target[1] - sy) / d * reach)


def scene(c, t):
    if CU[0] <= t < CU[1]:                                       # her face: which one is really bigger?
        u = (t - CU[0]) / (CU[1] - CU[0])
        c.save(); z = 1.0 + 0.06 * u; c.translate(540, 950); c.scale(z, z); c.translate(-540, -900)
        M.face_bg(c, t, KEYL, -1); k = smooth((u - 0.25) / 0.25)
        CH.face(c, t, look=lerp(-0.5, 0.5, k), looky=lerp(-0.7, 0.1, k), brow=0.1 + 0.95 * k, worry=0.6 * (1 - k) + 0.2, smile=-0.25 + 0.2 * k, lid=0.05 if 0.6 < u < 0.64 else 1.0, tilt=-5 + 10 * k, key=KEYL, key_side=-1)
        c.restore(); return
    if t < CU[0]:                                                # A wide: she points at Greenland, then across to Africa
        v = M.View(WIDE[0], WIDE[1], lerp(4.8, 4.95, t / CU[0]))
        gg = smooth((t - 0.45) / 0.3); ag = smooth((t - T_AF + 0.2) / 0.3)
        M.world(c, t, v, africa_glow=ag * (0.8 + 0.2 * math.sin(t * 6)), green_glow=gg * (0.8 + 0.2 * math.sin(t * 6)))
        rail(c)
        g, a = v.pt(-41, 72), v.pt(20, 5)
        k = ease_io((t - T_AF + 0.75) / 0.7); up = ease_io((t + 0.3) / 1.15)
        tgt = (lerp(g[0], a[0], k), lerp(g[1], a[1], k) - 60 * math.sin(math.pi * k))
        rest = CH.rest_hand(1); hp = aim_hand(tgt)
        sx, sy = CH.X0 + 106, CH.SHY + 14                     # the hand swings up on an arc out to her side (round the shoulder), never through it
        a0 = math.atan2(rest[1] - sy, rest[0] - sx); a1 = math.atan2(hp[1] - sy, hp[0] - sx)
        r0 = math.hypot(rest[0] - sx, rest[1] - sy); r1 = math.hypot(hp[0] - sx, hp[1] - sy)
        aa = lerp(a0, a1, up); rr = lerp(r0, r1, up); hp = (sx + rr * math.cos(aa), sy + rr * math.sin(aa))
        her(c, t, yaw=lerp(-0.1, 0.55, k) + 0.08 * math.sin(t * 2.4), tilt=-5 + 3 * math.sin(t * 1.9) + 8 * k, hr=hp, pr=tgt if up > 0.5 else None)
    elif t < T_EVERY - 0.05:                                     # C and D: inside the map
        vk = keys(VKEYS, t)
        v = M.View(*vk)
        sl = t >= T_SLIDE
        M.world(c, t, v, hide_greenland=sl, africa_glow=smooth((t - T_AF2) / 0.3) * (0.8 + 0.2 * math.sin(t * 5)) if t >= T_AF2 else 0.0)
        if t < T_TO + 1.0:
            a = 1 - smooth((t - T_TO) / 0.8)
            p0, p1 = v.pt(*LIS), v.pt(*BAR)
            lu = ease_io((t - T_STR + 0.2) / 1.1); su = ease_io((t - T_THIS + 0.4) / (T_TO + 0.6 - T_THIS + 0.4))
            c.drawCircle(*p0, 12, P(GOLD, 255 * a)); c.drawCircle(*p0, 6, P((30, 30, 60), 255 * a))          # the port she leaves from
            if lu > 0:
                q = (lerp(p0[0], p1[0], lu), lerp(p0[1], p1[1], lu))
                c.drawLine(*p0, *q, SP((20, 30, 70), 12, 90 * a, MaskFilter=blur(5))); c.drawLine(*p0, *q, SP(GOLD, 7, 255 * a))
            sp = (lerp(p0[0], p1[0], su * 0.92), lerp(p0[1], p1[1], su * 0.92) - 8 + 3 * math.sin(t * 2.2))
            c.saveLayerAlpha(None, int(255 * a)); M.ship(c, sp[0], sp[1], 0, t, 1.5); c.restore()
            A.tag(c, 'MERCATOR, 1569', 540, 560, Wt, 56, pop(t, T_MERC), a * (1.0 if t >= T_MERC else 0.0))
            M.compass(c, 800, 1110, 120, BEARING, a * smooth((t - at('sailors') + 0.2) / 0.3), t)
            if t >= T_ONE: A.tag(c, "ONE HEADING", 790, 1336, GOLD, 52, pop(t, T_ONE), a)
        ca = 1 - smooth((t - T_SLIDE + 0.35) / 0.3)
        if t >= T_TO + 0.9 and ca > 0.01:                        # equal circles on the globe, drawn the way this map must draw them
            for i, (la, lab) in enumerate(((0, 'x1'), (45, 'x1.4'), (60, 'x2'), (70, 'x3'))):
                k = pop(t, T_STRETCH - 0.3 + i * 0.42, 0.3)
                if k <= 0: continue
                x, y = v.pt(-30, la); r = 6.4 / math.cos(math.radians(la)) * v.s * k
                c.drawCircle(x, y, r, P((255, 255, 255), 70 * ca)); c.drawCircle(x, y, r, SP((255, 255, 255), 5, 255 * ca)); c.drawCircle(x, y, r, SP(GOLD, 2.5, 160 * ca))
                A.tag(c, lab, x + r + 84, y + 10, GOLD if i else Wt, 44, min(1.0, k), ca)
            xx, yy = v.pt(-30, 22); A.tag(c, 'SAME REAL SIZE', xx - 262, yy, Wt, 48, pop(t, T_STRETCH + 0.2), ca)
        if sl:                                                   # the equator, marked, so 'down to the equator' has somewhere to go
            ea_ = smooth((t - T_SLIDE) / 0.3) * (1 - smooth((t - T_AF2 + 0.2) / 0.3)); e0, e1 = v.pt(-180, 0), v.pt(180, 0)
            c.drawLine(0, e0[1], 1080, e1[1], skia.Paint(AntiAlias=True, Color=C(GOLD, 230 * ea_), Style=skia.Paint.kStroke_Style, StrokeWidth=5, PathEffect=skia.DashPathEffect.Make([22, 14], 0)))
            A.tag(c, 'EQUATOR', 924, e0[1] - 44, GOLD, 42, 1.0, ea_)
        if sl:                                                   # E: her hand comes in, presses on Greenland and drags it to the equator
            u = ease_io((t - T_GR2 + 0.1) / (T_SHRINK + 0.3 - T_GR2 + 0.1))
            cen = (lerp(72, 2, u), lerp(-41, 20, u))
            M.greenland_at(c, v, M.G0, dashed=True, a=smooth(u * 6))
            M.greenland_at(c, v, cen, lift=smooth((t - T_GR2 + 0.15) / 0.2) * (1 - smooth((t - T_SHRINK - 0.3) / 0.15)))
            gm = M.moved([[(-57.0, 76.0)]], M.G0, cen)[0][0]; g = v.pt(gm[0], gm[1]); ang = math.radians(9)       # two fingertips on its north west edge push it down and along; the hand stays clear of the shape
            reach = smooth((t - T_SLIDE) / 0.38); away = smooth((t - T_SHRINK - 0.42) / 0.5)
            press = 10 * smooth((t - T_GR2 + 0.2) / 0.12) * (1 - smooth((t - T_SHRINK - 0.3) / 0.12))
            tip = (g[0] + 9 - 520 * (1 - reach) - 900 * away, g[1] + 7 - 60 * (1 - reach) + 150 * away)
            L_ = PUSH_L - press
            wr = (tip[0] - L_ * math.cos(ang), tip[1] - L_ * math.sin(ang))
            fa = math.radians(-17)                                 # the forearm comes up from her elbow, lower and to the left; the wrist bends to lay the fingers down
            el = (wr[0] - 430 * math.cos(fa), wr[1] - 430 * math.sin(fa)); shd = (el[0] - 250, el[1] + 560)
            wb = (wr[0] - 16 * math.cos(fa), wr[1] - 16 * math.sin(fa))
            jn = skia.Path(); jn.addCircle(el[0], el[1], 57)
            sl_ = A.op(A.op(A.tube(shd, el, 150, 114), A.tube(el, wb, 110, 74)), jn)
            c.drawPath(sl_, P((20, 30, 70), 80, MaskFilter=blur(14)))
            A.shaded(c, sl_, CH.SW, CH.SW_SH, sh=(-14, -7), rimL=CH.SW_HI, rl=(6, 4))
            for (d0, d1, w_) in ((-34, 30, 6), (-12, 44, 5)):          # folds in the sleeve inside the bent elbow
                q = skia.Path(); q.moveTo(el[0] + 40 + d0 * 0.3, el[1] + 26 + d0 * 0.5); q.quadTo(el[0] + 6, el[1] + 30 + d1 * 0.3, el[0] - 30, el[1] + 44 + d1 * 0.5); c.drawPath(q, SP(CH.SW_SH, w_, 150))
            for k_ in (0.5, 0.72):                                  # soft wrinkles along the forearm
                mx, my = lerp(el[0], wb[0], k_), lerp(el[1], wb[1], k_); c.drawLine(mx - 4, my + 12, mx + 10, my + 34, SP(CH.SW_SH, 4, 110))
            cuff = A.tube((wr[0] - 40 * math.cos(fa), wr[1] - 40 * math.sin(fa)), (wr[0] + 2 * math.cos(fa), wr[1] + 2 * math.sin(fa)), 82, 76)
            c.drawPath(cuff, P(mix(CH.SW, (255, 255, 255), 0.22))); c.drawPath(A.diffp(cuff, (-7, -4)), P(CH.SW_SH))
            HN.hand(c, wr, ang, -1, 1.5, skin=CH.SKIN, shade=CH.SKIN_SH, hi=CH.SKIN_HI, nails=True, curls=(0.62, 0.03 + 0.05 * press / 10, 0.05 + 0.05 * press / 10, 0.86, 0.92), spread=0.12)
        if t >= T_AF2:
            A.tag(c, 'AFRICA', 520, 620, GOLD, 60, pop(t, T_AF2), 1.0)
            A.tag(c, '14x BIGGER', 610, 1290, Wt, 78, pop(t, T_14), 1.0 if t >= T_14 else 0.0)
            gx, gy = v.pt(20, 2)
            if t >= T_14 - 0.6: A.tag(c, 'GREENLAND', gx + 10, gy - 118, (200, 226, 255), 46, pop(t, T_14 - 0.6), 1.0)
    else:                                                        # G wide: what the map drew, and the real size
        u = (t - T_EVERY) / (DUR - T_EVERY)
        v = M.View(WIDE[0], WIDE[1], lerp(4.95, 4.8, ease_io(u)))
        M.world(c, t, v, hide_greenland=False); rail(c)
        M.greenland_at(c, v, (2, 20))
        g, a = v.pt(-41, 72), v.pt(20, 2)
        A.tag(c, 'ON THE MAP', g[0] + 6, g[1] + 40, Wt, 44, pop(t, T_BEND), 1.0 if t >= T_BEND else 0.0)
        A.tag(c, 'REAL SIZE', a[0] - 6, a[1] - 98, GOLD, 46, pop(t, T_THIS2 + 0.3), 1.0 if t >= T_THIS2 + 0.3 else 0.0)
        up = ease_io((t - T_THIS2 + 0.35) / 0.8) * (1 - ease_io((t - T_END + 0.25) / 0.9))        # she lowers her arm again at the end
        rest = CH.rest_hand(1); hp = aim_hand(a); sx, sy = CH.X0 + 106, CH.SHY + 14
        a0 = math.atan2(rest[1] - sy, rest[0] - sx); a1 = math.atan2(hp[1] - sy, hp[0] - sx)
        r0 = math.hypot(rest[0] - sx, rest[1] - sy); r1 = math.hypot(hp[0] - sx, hp[1] - sy)
        aa = lerp(a0, a1, up); rr = lerp(r0, r1, up); hp = (sx + rr * math.cos(aa), sy + rr * math.sin(aa))
        yaw = keys([(T_EVERY, 0.5), (T_EVERY + 0.9, 0.22), (T_BEND + 0.3, 0.2), (T_THIS2 + 0.3, 0.55), (T_THIS2 + 0.95, 0.55), (T_THIS2 + 1.35, 0.25), (T_END - 0.3, 0.5), (T_END + 0.2, 0.1), (T_END + 0.7, 0.62), (DUR, 0.5)], t)[0]
        tilt = keys([(T_EVERY, 3), (T_EVERY + 0.9, -6), (T_BEND + 0.3, -6), (T_THIS2 + 0.3, 3), (T_END + 0.6, 3), (T_END + 0.85, 9), (T_END + 1.15, 1), (DUR, 3)], t)[0]
        her(c, t, yaw=yaw, tilt=tilt, hr=hp if up > 0.01 else None, pr=a if up > 0.55 and t < T_END - 0.2 else None)


VKEYS = [(T_THIS, -34, 30, 8.0), (T_DIR + 0.6, -36, 28, 8.6), (T_TO + 1.3, -30, 50, 4.5), (T_SLIDE - 0.2, -30, 52, 4.7), (T_GR2, -14, 50, 4.9), (T_SHRINK + 0.3, -8, 44, 5.0),
         (T_AF2 + 0.9, 15, 7, 8.4), (T_EVERY, 17, 4, 9.0)]

TITLES = [
    (0.0, [[('GREENLAND VS ', Wt), ('AFRICA', Y)], [('WHICH IS REALLY ', Wt), ('BIGGER?', Y)]]),
    (T_THIS, [[('A MAP MADE', Wt)], [('FOR ', Wt), ('SAILORS', Y)]]),
    (T_STR, [[('A STRAIGHT LINE', Wt)], [('IS ONE ', Wt), ('COMPASS HEADING', Y)]]),
    (T_TO, [[('BUT THE LAND GETS', Wt)], [('STRETCHED', R), (' NEAR THE POLES', Wt)]]),
    (T_SLIDE, [[('SLIDE GREENLAND', Wt)], [('TO THE ', Wt), ('EQUATOR', TL)]]),
    (T_SHRINK - 0.3, [[('WATCH IT', Wt)], [('SHRINK', TL)]]),
    (T_AF2, [[('AFRICA IS ACTUALLY', Wt)], [('14 TIMES', Y), (' BIGGER', Wt)]]),
    (T_EVERY, [[('EVERY FLAT MAP', Wt)], [('BENDS ', Wt), ('SOMETHING', Y)]]),
    (T_THIS2, [[('THIS ONE', Wt)], [('BENDS ', Wt), ('SIZE', Y)]]),
]

SHORT = Short(WD, 'AP HUMAN GEOGRAPHY', TITLES, scene, DUR, T_END, lift=lambda t: 1.0, fix={'FOURTEEN': 'fourteen'}, cuts=(T_THIS,))

if __name__ == '__main__':
    out, st = kit.args()
    kit.render(SHORT, out, stills=st, outdir=os.environ.get('STILLS', '/home/claude/w1124/map/out/stills'))
