"""Art for w1124-03-greenland-africa: a Mercator wall map drawn from real country outlines (Natural Earth 110m), true size re projection,
a caravel on a rhumb line, circles of equal real size. Map units: x = longitude in degrees, y = Mercator northing in the same units."""
import sys, math, warnings
sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/lib']
warnings.filterwarnings('ignore')
import numpy as np, skia, geopandas as gpd
from lpk import P, SP, C, blur, smooth, lerp, mix, poly, smooth_closed
from art import shaded, diffp, glow, SCREEN


def my(lat):
    lat = max(-84.0, min(84.5, lat)); return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))


_W = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
CONT_COL = {'Africa': (240, 170, 84), 'Europe': (176, 150, 208), 'Asia': (228, 138, 128), 'North America': (130, 190, 130), 'South America': (232, 140, 160),
            'Oceania': (232, 206, 110), 'Seven seas (open ocean)': (200, 200, 200), 'Antarctica': (240, 244, 248)}
OCEAN, OCEAN_D, ICE = (120, 186, 214), (92, 160, 196), (244, 248, 252)


def _rings(geom):
    gs = geom.geoms if geom.geom_type == 'MultiPolygon' else [geom]
    return [list(g.exterior.coords) for g in gs]


def _path(rings, proj=lambda lo, la: (lo, -my(la))):
    p = skia.Path()
    for r in rings:
        p.moveTo(*proj(*r[0]))
        for q in r[1:]: p.lineTo(*proj(*q))
        p.close()
    return p


LAND = []; AFRICA = skia.Path(); GREEN_RINGS = None
for _, r in _W.iterrows():
    if r['continent'] == 'Antarctica': continue
    rings = _rings(r.geometry)
    if r['name'] == 'Greenland': GREEN_RINGS = [max(rings, key=len)]; col = ICE
    else: col = CONT_COL.get(r['continent'], (200, 200, 200))
    k = (hash(r['name']) % 7 - 3) * 0.022                   # neighbours differ a little, like a political wall map
    col = tuple(max(0, min(255, v * (1 + k))) for v in col) if r['name'] != 'Greenland' else col
    pth = _path(rings); LAND.append((pth, col, r['name']))
    if r['continent'] == 'Africa': AFRICA.addPath(pth)
G0 = (72.0, -41.0)                                          # Greenland's middle (lat, lon)


def moved(rings, c0, c1):
    """carry a shape across the globe from centre c0 to c1 keeping its real size and shape (each point keeps its distance and bearing from
    the centre), so on the Mercator map it is drawn the size the map gives that latitude"""
    la0, lo0 = math.radians(c0[0]), math.radians(c0[1]); la1, lo1 = math.radians(c1[0]), math.radians(c1[1]); out = []
    for r in rings:
        rr = []
        for lo, la in r:
            la_, lo_ = math.radians(la), math.radians(lo)
            d = math.acos(max(-1, min(1, math.sin(la0) * math.sin(la_) + math.cos(la0) * math.cos(la_) * math.cos(lo_ - lo0))))
            b = math.atan2(math.sin(lo_ - lo0) * math.cos(la_), math.cos(la0) * math.sin(la_) - math.sin(la0) * math.cos(la_) * math.cos(lo_ - lo0))
            la2 = math.asin(max(-1, min(1, math.sin(la1) * math.cos(d) + math.cos(la1) * math.sin(d) * math.cos(b))))
            lo2 = lo1 + math.atan2(math.sin(b) * math.sin(d) * math.cos(la1), math.cos(d) - math.sin(la1) * math.sin(la2))
            rr.append((math.degrees(lo2), math.degrees(la2)))
        out.append(rr)
    return out


class View:
    def __init__(self, clon, clat, s): self.clon, self.cmy, self.s = clon, my(clat), s
    def pt(self, lon, lat): return (540 + (lon - self.clon) * self.s, 900 - (my(lat) - self.cmy) * self.s)
    def apply(self, c): c.translate(540, 900); c.scale(self.s, self.s); c.translate(-self.clon, self.cmy)


def world(c, t, v, hide_greenland=False, africa_glow=0.0, green_glow=0.0):
    """the wall map: printed ocean, graticule, countries as flat colour with a paper edge shadow"""
    c.drawRect(skia.Rect(0, 0, 1080, 1920), P(OCEAN))
    c.save(); v.apply(c)
    for la in range(-60, 85, 15):
        c.drawLine(-400, -my(la), 400, -my(la), SP(OCEAN_D, (1.6 if la else 3.0) / v.s, 200 if la else 255))
    for lo in range(-360, 361, 15): c.drawLine(lo, -200, lo, 200, SP(OCEAN_D, 1.6 / v.s, 200))
    for dx in (0,):
        for pth, col, name in LAND:
            if hide_greenland and name == 'Greenland': continue
            c.drawPath(pth, P((40, 90, 130), 90, MaskFilter=blur(0.5)))
            c.drawPath(pth, P(col))
            c.save(); c.clipPath(pth, skia.ClipOp.kIntersect, True)
            q = skia.Path(pth); q.offset(1.1, 1.1); d = skia.Op(pth, q, skia.PathOp.kDifference_PathOp)
            if d is not None: c.drawPath(d, P((255, 255, 255), 110))
            q = skia.Path(pth); q.offset(-1.3, -1.3); d = skia.Op(pth, q, skia.PathOp.kDifference_PathOp)
            if d is not None: c.drawPath(d, P(mix(col, (60, 40, 80), 0.45), 150))
            c.restore()
            c.drawPath(pth, SP(mix(col, (50, 40, 70), 0.55), 0.9 / v.s * 2, 200))
    if africa_glow > 0.01:
        c.drawPath(AFRICA, SP((255, 226, 110), 5 / v.s * (1 + 0.3 * africa_glow), 255 * min(1, africa_glow))); c.drawPath(AFRICA, SP((255, 226, 110), 16 / v.s, 70 * min(1, africa_glow), MaskFilter=blur(6 / v.s)))
    if green_glow > 0.01:
        g = _path(GREEN_RINGS); c.drawPath(g, SP((255, 226, 110), 5 / v.s * (1 + 0.3 * green_glow), 255 * min(1, green_glow))); c.drawPath(g, SP((255, 226, 110), 16 / v.s, 70 * min(1, green_glow), MaskFilter=blur(6 / v.s)))
    c.restore()
    c.drawRect(skia.Rect(0, 0, 1080, 1920), skia.Paint(Shader=skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(1080, 1920)], [C((255, 250, 230), 30), C((40, 40, 90), 46)])))   # the print catching the window light


def greenland_at(c, v, centre, lift=0.0, a=1.0, dashed=False):
    rings = moved(GREEN_RINGS, G0, centre) if centre != G0 else GREEN_RINGS
    p = _path(rings)
    c.save(); v.apply(c)
    if dashed:
        c.drawPath(p, skia.Paint(AntiAlias=True, Color=C((255, 255, 255), 230 * a), Style=skia.Paint.kStroke_Style, StrokeWidth=3.2 / v.s, PathEffect=skia.DashPathEffect.Make([10 / v.s, 8 / v.s], 0)))
        c.restore(); return
    if lift > 0.01:
        q = skia.Path(p); q.offset(lift * 12 / v.s, lift * 16 / v.s); c.drawPath(q, P((20, 30, 70), 110 * lift * a, MaskFilter=blur(8 / v.s)))
    c.drawPath(p, P(ICE, 255 * a))
    q = skia.Path(p); q.offset(-1.4, -1.4); d = skia.Op(p, q, skia.PathOp.kDifference_PathOp)
    if d is not None: c.drawPath(d, P((176, 200, 226), 220 * a))
    c.drawPath(p, SP((90, 120, 170), 2.2 / v.s, 255 * a))
    c.restore()


def ship(c, x, y, ang, t, s=1.0):
    """a small caravel seen side on, sailing along its line; it rocks a little on the swell"""
    c.save(); c.translate(x, y); c.rotate(4 * math.sin(t * 2.2)); c.scale(s, s)
    for k in range(4): c.drawOval(skia.Rect(30 + k * 34, 10 - k * 2, 60 + k * 40, 20 - k * 2), P((240, 250, 255), 150 - k * 30))      # wake behind (it sails left)
    hull = smooth_closed([(-46, -4), (-30, 16), (26, 16), (44, -8), (30, -2), (-30, -2)])
    c.drawPath(hull, P((120, 70, 50))); c.drawPath(diffp(hull, (0, -6)), P((84, 44, 40))); c.drawRect(skia.Rect(-3, -64, 3, 0), P((84, 44, 40)))
    sw = 5 * math.sin(t * 2.2)
    sail = smooth_closed([(-2, -62), (-34 - sw, -40), (-30 - sw, -14), (-2, -8)]); c.drawPath(sail, P((250, 244, 228))); c.drawPath(diffp(sail, (5, 0)), P((206, 196, 180)))
    sail2 = smooth_closed([(6, -52), (28, -30), (6, -10)]); c.drawPath(sail2, P((236, 226, 206)))
    c.drawPath(poly([(-3, -64), (-22, -70), (-3, -76)]), P((220, 70, 70)))
    c.restore()


def compass(c, x, y, r, bearing, a=1.0, t=0.0):
    """a ship's compass: the needle keeps pointing north (it only trembles); the heading is a separate gold mark on the rim"""
    if a <= 0.01: return
    c.drawCircle(x, y, r, P((8, 12, 34), 236 * a)); c.drawCircle(x, y, r, SP((255, 255, 255), 5, 230 * a))
    f = skia.Font(skia.Typeface('Inter', skia.FontStyle.Bold()), r * 0.28)
    for lab, ang in (('N', -90), ('E', 0), ('S', 90), ('W', 180)):
        w = f.measureText(lab); c.drawString(lab, x + r * 0.7 * math.cos(math.radians(ang)) - w / 2, y + r * 0.7 * math.sin(math.radians(ang)) + r * 0.1, f, P((255, 255, 255), 230 * a))
    c.save(); c.translate(x, y); c.rotate(2.5 * math.sin(t * 5.3) * math.exp(-0.0 * t))
    c.drawPath(poly([(0, -r * 0.5), (r * 0.1, 0), (-r * 0.1, 0)]), P((255, 110, 110), 255 * a)); c.drawPath(poly([(0, r * 0.5), (r * 0.1, 0), (-r * 0.1, 0)]), P((230, 236, 246), 255 * a))
    c.restore(); c.drawCircle(x, y, r * 0.07, P((255, 255, 255), 255 * a))
    c.save(); c.translate(x, y); c.rotate(bearing)                                                       # the course she steers, fixed
    c.drawLine(0, -r * 0.2, 0, -r * 0.92, SP((255, 226, 110), 5, 255 * a, PathEffect=skia.DashPathEffect.Make([10, 8], 0)))
    c.drawPath(poly([(0, -r * 1.2), (r * 0.16, -r * 0.94), (-r * 0.16, -r * 0.94)]), P((255, 226, 110), 255 * a))
    c.restore()


def face_bg(c, t, key=(255, 236, 200), key_side=-1):
    sh = skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, 1920)], [C((214, 196, 170)), C((190, 168, 150)), C((120, 100, 110))], [0, 0.55, 1])
    c.drawRect(skia.Rect(0, 0, 1080, 1920), skia.Paint(Shader=sh))
    c.saveLayer(None, skia.Paint(ImageFilter=skia.ImageFilters.Blur(16, 16)))
    c.drawRect(skia.Rect(620, 380, 1000, 900), P((150, 200, 226))); c.drawRect(skia.Rect(800, 380, 812, 900), P((240, 240, 236))); c.drawRect(skia.Rect(620, 630, 1000, 642), P((240, 240, 236)))   # a window
    c.drawRect(skia.Rect(60, 460, 420, 760), P((60, 96, 84))); c.drawRect(skia.Rect(60, 760, 420, 784), P((150, 110, 80)))                                                                 # a chalkboard
    for i in range(4): c.drawRect(skia.Rect(-40 + i * 300, 1250, 200 + i * 300, 1300), P((150, 110, 80))); c.drawRect(skia.Rect(-20 + i * 300, 1300, 0 + i * 300, 1920), P((110, 84, 70)))
    c.restore()
    glow(c, 540 + key_side * 620, 700, 900, key, 80)
