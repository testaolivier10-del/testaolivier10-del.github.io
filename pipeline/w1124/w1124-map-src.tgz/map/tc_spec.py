SPEC = {"beats": [{"vo": open("/home/claude/w1124/map/vo.txt").read().strip()}]}
