import sys; sys.path[:0] = ['/home/claude/short', '/home/claude/w1124/map', '/home/claude/w1124/lib']
import build as B
import mixlib as X
OUT = '/home/claude/w1124/map/out'
fx = [('pen_scratch_real', B.T_STR - 0.2, 0.6, 1.0, 0.3, 0.0),             # the course line is ruled across the chart
      ('page_flip_real', B.T_SLIDE + 0.05, 0.8, 0.5, 0.25, 0.0),           # Greenland lifts off the paper
      ('bagdrop_real', B.T_SHRINK + 0.3, 0.45, 0.35, 0.25, 0.0),           # it settles onto Africa
      (X.tick(1400, 0.08), B.T_14, 0.8, None, 0.05, 0.0)]                  # the count lands
secs = [(0, 6.5), (6.5, 15.0), (15.0, 20.2), (20.2, 24.1), (24.1, 27.5), (27.5, B.DUR)]
X.mix(OUT, '/home/claude/w1124/map/snd/a.mp3', B.DUR, fx, None, secs, [(0, 1.0), (B.T_AF2, 1.0), (B.T_14, 1.25), (B.T_EVERY, 1.0), (B.DUR, 1.15)])
if '--encode' in sys.argv: X.encode(OUT)
